# db_connection.py
import psycopg2

from logger.logger import *


def get_db_connection(database_credentials):
    try:
        connection = psycopg2.connect(
            dbname=database_credentials['@dbname'],
            user=database_credentials['@user'],
            password=database_credentials['@password'],
            host=database_credentials['@host'],
            port=database_credentials['@port']
        )
        return connection
    except (Exception, psycopg2.Error) as error:
        logger_error(f"Error while connecting to PostgreSQL: {error}")
        exit()
