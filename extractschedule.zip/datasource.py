import argparse
import json
import os
import re
import tempfile
import time
import shutil
# from msystem import sys_variables
import urllib.parse
import xml.etree.ElementTree as ET

import openpyxl
import pandas as pd
import requests
import tableauserverclient as TSC
from openpyxl.styles import Font
from tableauserverclient import *
from tabulate import tabulate
from connection import login_to_tableau,get_all_items

from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from pypac import pac_context_for_url

base_url = ""
cloud_url = ""

temp_dir_list=[]
datasourcesname = []
log = []
migrate = []

def query_tableau_datasources(
    api_version,
    site_id,
    page_size=1,
    page_number=1,
    filter_expression=None,
    sort_expression=None,
    field_expression=None,
):
    url = f"{base_url}/{api_version}/sites/{site_id}/datasources"

    params = {}
    if page_size:
        params["pageSize"] = page_size
    if page_number:
        params["pageNumber"] = page_number
    if filter_expression:
        params["filter"] = filter_expression
    if sort_expression:
        params["sort"] = sort_expression
    if field_expression:
        params["fields"] = field_expression

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # This will raise an exception for HTTP errors

        # Parse XML response
        root = ET.fromstring(response.content)
        data_sources = []
        for datasource in root.findall(".//datasource"):
            ds_info = {
                "id": datasource.get("id"),
                "name": datasource.get("name"),
                "description": datasource.get("description"),
                "type": datasource.get("type"),
                "contentUrl": datasource.get("contentUrl"),
                "createdAt": datasource.get("createdAt"),
                "updatedAt": datasource.get("updatedAt"),
                "isCertified": datasource.get("isCertified"),
                "tags": [tag.get("label") for tag in datasource.findall(".//tag")],
            }
            data_sources.append(ds_info)

        return data_sources

    except requests.exceptions.HTTPError as e:
        status_code = e.response.status_code
        if status_code == 400:
            if "400006" in e.response.text:
                return "Error: Invalid page number."
            elif "400007" in e.response.text:
                return "Error: Invalid page size."
        elif status_code == 403 and "403014" in e.response.text:
            return "Error: Page size limit exceeded."
        elif status_code == 404:
            return "Error: Site not found."
        elif status_code == 405:
            return "Error: Invalid request method - only GET is allowed."
        else:
            return f"HTTP Error: {status_code} - {e.response.reason}"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"


def download_tableau_datasource(
    api_version, site_id, datasource_id, include_extract=True
):
    url = (
        f"{base_url}/{api_version}/sites/{site_id}/datasources/{datasource_id}/content"
    )

    # Include the extract parameter based on the function argument
    if not include_extract:
        url += "?includeExtract=False"

    try:
        response = requests.get(url)
        response.raise_for_status()  # This will raise an exception for HTTP errors

        # Check content type
        if response.headers["Content-Type"] == "application/octet-stream":
            content_disposition = response.headers.get("Content-Disposition", "")
            filename = (
                content_disposition.split("filename=")[1]
                if "filename=" in content_disposition
                else "downloaded_datasource.tdsx"
            )

            # Save the file
            with open(filename, "wb") as f:
                f.write(response.content)
            return f"Data source downloaded successfully: {filename}"
        else:
            return "Unexpected content type received; expected binary data."

    except requests.exceptions.HTTPError as e:
        status_code = e.response.status_code
        if status_code == 403:
            return "Error: Read forbidden - you do not have permission to download this data source."
        elif status_code == 404:
            if "404004" in e.response.text:
                return "Error: Data source not found."
            elif "404000" in e.response.text:
                return "Error: Site not found."
            return "Error: Resource not found."
        elif status_code == 405:
            return "Error: Invalid request method - only GET is allowed."
        else:
            return f"HTTP Error: {status_code} - {e.response.reason}"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"


def show_in_table(data=None, headers=None):
    """
    Show the datasources in a table
    :param datasource_project_map:
    :return:
    """
    print(tabulate(data, headers=headers, tablefmt="grid"))


def get_datasources_from_projects(server, value=None):
    """
    Download all the datasources from a project
    :param server:
    :param project_id:
    :param target:
    :return:
    """
    logger_info(f"Getting datasources from the project : {value.split('|')}")
    projects_list = value.split("|")
    projects = server.projects.get()[0]

    project_id_map = {}
    for project in projects_list:
        for project_item in projects:
            if project == project_item.name:
                project_id_map[project_item.id] = project

    datasources = server.datasources.get()[0]
    datasource_project_map = {}
    for datasource in datasources:
        if datasource.project_id in project_id_map.keys():
            datasource_project_map[datasource] = project_id_map[datasource.project_id]

    # show data in table format
    print("Datasources found in projects")
    headers = ["Datasource Name", "Project Name", "Project ID"]
    data = [
        [datasource.name, project_id_map[datasource.project_id], datasource.project_id]
        for datasource in datasource_project_map.keys()
    ]
    show_in_table(data=data, headers=headers)
    return datasource_project_map


def get_datasources_from_tags(server, value=None):
    """
    Get all the datasources from the project
    :param server:
    :param project_id:
    :return:
    """
    # Get all the datasources from the project
    logger_info(f"Getting datasources having tags : {value.split('|')}")
    tag_list = value.split("|")
    project_id_map = {}
    projects = server.projects.get()[0]
    for tag in tag_list:
        datasource = server.datasources.filter(tags=tag)
        for ds in datasource:
            for project in projects:
                if ds.project_id == project.id:
                    project_id_map[ds] = project

    # show data in table format
    print("\n\nDatasources found with the given tags")
    headers = ["Datasource Name", "tag name", "Project Name", "Project ID"]
    data = [
        [
            datasource.name,
            datasource.tags,
            project_id_map[datasource].name,
            project_id_map[datasource].id,
        ]
        for datasource, tag in project_id_map.items()
    ]
    show_in_table(data=data, headers=headers)
    return project_id_map


def get_datasources_from_name(server, value=None):
    """
    Get all the datasources from the project
    :param server:
    :param project_id:
    :return:
    """
    logger_info(f"Getting datasources having names : {value.split('|')}")
    name_list = value.split("|")
    projects = server.projects.get()[0]
    datasource_project_map = {}
    for name in name_list:
        datasource = server.datasources.filter(name=name)
        for ds in datasource:
            for project in projects:
                if ds.project_id == project.id:
                    datasource_project_map[ds] = project

    # show in table
    print("\n\nDatasources found with the given names")
    headers = ["Datasource Name", "Project Name", "Project ID"]
    data = [
        [
            datasource.name,
            datasource_project_map[datasource].name,
            datasource_project_map[datasource].id,
        ]
        for datasource in datasource_project_map.keys()
    ]
    show_in_table(data=data, headers=headers)
    return datasource_project_map

def get_all_datasources(server, value=None):
    """
    Get all the datasources from the site
    :param server:
    :param value:
    :return:
    """
    logger_info(f"Getting all the datasources from the site")
    projects = server.projects.get()[0]
    datasources = server.datasources.get()[0]

    datasource_project_map = {}
    for datasource in datasources:
        for project in projects:
            if datasource.project_id == project.id:
                datasource_project_map[datasource] = project

    # show in table
    print("\n\nDatasources found in the site")
    headers = ["Datasource Name", "Project Name", "Project ID"]
    data = [
        [datasource.name, datasource_project_map[datasource].name, datasource_project_map[datasource].id]
        for datasource in datasources
    ]
    show_in_table(data=data, headers=headers)
    return datasource_project_map

def download_datasources(datasources_project_map):
    """
    Download the datasources from the server
    :param datasources_project_map:
    :return:
    """
    temp_dir = tempfile.mkdtemp()
    temp_dir_list.append(temp_dir)
    for server, ds_p_map in datasources_project_map.items():
        for each_datasource in ds_p_map:
            file_path = os.path.join(temp_dir, each_datasource.name)
            server.datasources.download(each_datasource.id, filepath=file_path)
    return temp_dir

def get_project_id(projects, project_path,server):
    # Base case: If the project path is empty, return None
    if not project_path:
        return None

    current_project = None
    for project in projects:
        if project.name.lower() == project_path[1].lower():  # Case-insensitive comparison
            current_project = project
            break

    if current_project is None:
        return None

    for part in project_path[2:]:
        child_projects = [p for p in TSC.Pager(server.projects) if p.parent_id == current_project.id]
        current_project = None
        for child in child_projects:
            if child.name.lower() == part.lower():  # Case-insensitive comparison
                current_project = child
                break

        if current_project is None:
            return None

    return current_project.id

def get_project(cloud_server, project_name):
    """
    Get a top-level project by its name, ignoring case.
    :param cloud_server: Tableau Server or Tableau Online instance
    :param project_name: Name of the top-level project
    :return: Project object if found, else None
    """
    all_projects, _ = cloud_server.projects.get()
    for project in all_projects:
        if project.name.lower() == project_name.lower():
            return project
    return None


def get_subproject(cloud_server, parent_project_id, subproject_name):
    """
    Get a subproject by its name and parent project ID, ignoring case.
    :param cloud_server: Tableau Server or Tableau Online instance
    :param parent_project_id: ID of the parent project
    :param subproject_name: Name of the subproject
    :return: Subproject object if found, else None
    """
    all_projects, _ = cloud_server.projects.get()
    for project in all_projects:
        if project.parent_id == parent_project_id and project.name.lower() == subproject_name.lower():
            return project
    return None

def create_temp_dir(user_path=None):
    """
    Create a temporary directory in the specified path or the current directory.

    Args:
    user_path (str): The directory path where the temporary directory should be created.
                     If not specified, the current directory is used.

    Returns:
    str: The path to the created temporary directory.
    """
    # If user_path is provided, use it; otherwise, use the current working directory
    if user_path:
        # Ensure the path is absolute
        base_path = os.path.abspath(user_path)
    else:
        base_path = os.getcwd()

    # Ensure the base path exists
    if not os.path.exists(base_path):
        logger_error(f"The specified path does not exist: {base_path}")
        exit(1)

    # Check if we have permission to write in the directory
    if not os.access(base_path, os.W_OK):
        logger_error(f"Write permission denied for the path: {base_path}")
        exit(1)

    # Create a temporary directory within the specified path
    try:
        temp_dir = tempfile.mkdtemp(dir=base_path)
        temp_dir_list.append(temp_dir)
    except PermissionError as e:
        logger_error(f"Failed to create a temporary directory: {e}")
        exit(1)

    return temp_dir

def download(server, project_paths):
    with pac_context_for_url('https://srvtblupwvsu201.shusapro.santanderholdingsusa.corp'):
        tableau_server=login_to_tableau(server)
        with tableau_server[0].auth.sign_in(tableau_server[1]):

                datasources_Details = []
                description = []
                temp_dir =create_temp_dir()
                all_datasource = get_all_items(tableau_server[0], 'datasource')
                for project_path in project_paths:
                    # Split the project path into components
                    project_path_components = project_path.strip('/').split('/')

                    # Initialize variables to track the current project hierarchy
                    current_project = None

                    current_project=get_project_ids(project_path,tableau_server[0])
                    # Get all data sources in the specified project
                    project_datasource_items = [
                        ds for ds in all_datasource if ds.project_id == current_project
                    ]
                    names = [datasource.name for datasource in project_datasource_items]
                    logger_info(f"Downloaded datasource: {names}")
                    logger_info(f"Total number of data sources in project '{project_path}': {len(names)}")

                    # Download the data sources in the temp folder
                    for datasource in project_datasource_items:
                        # Construct the folder path for the project hierarchy
                        encoded_path_components = [urllib.parse.quote(component) for component in project_path_components]
                        sanitized_path_components = [sanitize_filename(component) for component in encoded_path_components]
                        project_folder = os.path.join(temp_dir, *sanitized_path_components)

                        # Create folders for the project hierarchy if they don't exist
                        if not os.path.exists(project_folder):
                            os.makedirs(project_folder)

                        # print("datasource.name",datasource.name)
                        datasource.name=datasource.name.replace('/', '_fwd_SLASH_')
                        # Define the file path for the data source
                        encoded_datasource_name = urllib.parse.quote(datasource.name)
                        sanitized_datasource_name = sanitize_filename(encoded_datasource_name)
                        file_path = os.path.join(project_folder, sanitized_datasource_name)

                        try:

                            datasource = tableau_server[0].datasources.get_by_id(datasource.id)
                                # print("workbook",workbook)
                            tableau_server[0].datasources.populate_connections(datasource)
                            datasources = TSC.Pager(tableau_server[0].datasources)

                            for connection in datasource.connections:
                                datasources_Details.append({
                                                "datasource_id":datasource.id,
                                                "datasource_name":datasource.name,
                                                "filepath": file_path,
                                                "server_address": connection.server_address,
                                                "server_port": connection.server_port,
                                                "connection_type": connection.connection_type,
                                                "connection_username": connection.username,
                                                "connection_password": connection.password,
                                                "connection_embed_password": connection.embed_password,
                                            })
                            description.append({"filepath": file_path,"description": datasource.description})
                            tableau_server[0].datasources.download(datasource.id, filepath=file_path)
                            logger_info(f"Downloaded data source '{datasource.name}' to '{file_path}'")
                        except Exception as e:
                            logger_error(f"Failed to download data source '{datasource.name}': {e}")

                # Return the path to the downloaded data sources
                cloud_datasource = temp_dir
                return cloud_datasource,datasources_Details,description


def sanitize_filename(filename):
    """     Remove or replace characters that are invalid for filenames on Windows.     """
    # Replace invalid characters with an underscore
    return re.sub(r'[<>:"/\\|?*]','_', filename)

def sanitize_filenames(filename):
    """     Remove or replace characters that are invalid for filenames on Windows.     """
    # Replace invalid characters with an underscore
    return re.sub(r'[<>:"\\|?*]','_', filename)

def split_path(destination_path):
    # Find the index of the last '/'
    last_slash_index = destination_path.rfind('/')
    
    if last_slash_index == -1:
        # If there's no '/', return the entire path as a single element list
        return [destination_path]
    
    # Split the path into main path and project name
    main_path = destination_path[:last_slash_index]
    project_name = destination_path[last_slash_index + 1:]
    
    # Split the main path by '/' and add the project name as the last element
    path_parts = main_path.split('/') + [project_name]
    
    return path_parts

def get_child_project_id(projects, project_path,server):
    # Base case: If the project path is empty, return None
    if not project_path:
        return None
    for project in projects:
        project_path_ = project_path[0].replace('_fwd_SLASH_', '/')
        if project.name.lower() == project_path_.lower():
            if len(project_path) == 1:
                return project.id
            else:
                child_projects = [p for p in TSC.Pager(server.projects) if p.parent_id == project.id]
                child_project_id = get_child_project_id(child_projects, project_path[1:],server)
                if child_project_id:
                    return child_project_id
    return None

def get_project_ids(path, server):
    all_projects=list(TSC.Pager(server.projects))
    main_path=path[1:]
    if'/' in main_path:
        path_parts = main_path.split('/')
        return get_child_project_id(all_projects, path_parts, server)
    else:
        for pro in all_projects:
            if pro.name.lower() == main_path.lower() and pro.parent_id is None:
                return pro.id
    return None

def migrate_datasources(cloud_server, datasources_dir, paths, datasources_Details,descriptions):
    """
    Publish the datasources to the specified projects on the cloud.
    :param cloud_server: Tableau Server or Tableau Online instance
    :param datasources_dir: Directory path containing local datasource directories
    :param paths: List of lists containing source and destination paths
    """
    logger_info("------Starting publishing specific datasources------")

    total_specific_datasources = 0  # Initialize counter for specific datasources processed
    total_specific_published = 0  # Initialize counter for specific datasources successfully published
    total_specific_failed = 0  # Initialize counter for specific datasources failed to publish

    failed_datasources = []  # List to store names of failed datasources

    # Ensure paths is a list of lists
    if not all(isinstance(entry, list) and len(entry) == 2 for entry in paths):
        logger_error("Invalid format for paths. Expected a list of lists with two elements each.")
        return

    # Iterate through the list and publish each datasource
    for path_entry in paths:
        source_path, destination_path = path_entry

        # Combine the base directory with the relative source path
        encoded_source_path = urllib.parse.quote(source_path.lstrip('/'), safe='/')
        full_source_path = os.path.join(datasources_dir, encoded_source_path)

        # Check if the path exists and is a directory
        if os.path.exists(full_source_path) and os.path.isdir(full_source_path):
            destination_project=get_project_ids(destination_path,cloud_server)
            for root, dirs, files in os.walk(full_source_path):
                if root != full_source_path:
                    continue
                for file in files:
                    file_path = os.path.join(root, file)
                    if os.path.isfile(file_path):
                        # Sanitize and rename the file if necessary
                        file_name = os.path.basename(file)
                        decoded_file_name = urllib.parse.unquote(file_name)
                        sanitized_file_name = sanitize_filename(decoded_file_name)
                        decoded_file_path = os.path.join(root, sanitized_file_name)
                        if file_path != decoded_file_path:
                            os.rename(file_path, decoded_file_path)
                        if decoded_file_name.endswith(".tds"):
                            datasource_name = decoded_file_name[:-4]
                        elif decoded_file_name.endswith(".tdsx"):
                            datasource_name = decoded_file_name[:-5]
                        datasource_name = datasource_name.replace('_fwd_SLASH_', '/')

                        if destination_project:
                            try:
                                logger_info(f"Publishing {datasource_name} datasource to {destination_path} project")
                                datasource_item = DatasourceItem(destination_project, name=datasource_name)
                                published_datasource = cloud_server.datasources.publish(
                                    datasource_item,
                                    decoded_file_path,
                                    mode='Overwrite',
                                    connection_credentials=None,
                                )
                                # Log successful publication
                                logger_info(f"\t\tDatasource published successfully: {datasource_name}")
                                datasourcesname.append(datasource_name)
                                log.append(f"Datasource migrated successfully")
                                migrate.append('Migrated Datasource')
                                total_specific_published += 1  # Increment counter
                                set_description = ''
                                for description in descriptions:
                                    if file_path.endswith('.tdsx') or file_path.endswith('.tds'):
                                        rename_file_path = file_path[:-5]
                                    rename_file_path = rename_file_path.replace('/','\\')
                                    if description['filepath'] == rename_file_path:
                                        set_description = description['description']
                                        break

                                if set_description is not None:
                                    url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/datasources/{published_datasource.id}"
                                    headers = {
                                        "Content-Type": "application/xml",
                                        "X-Tableau-Auth": cloud_server.auth_token
                                    }
                                    # Assuming datasource_name and set_description are defined variables
                                    ts_request = ET.Element('tsRequest')

                                    datasource_elem = ET.SubElement(ts_request, 'datasource', {
                                        'description': set_description
                                    })

                                    # Convert the ElementTree object to a string representation of XML
                                    payload = ET.tostring(ts_request, encoding='utf-8', method='xml')
                                    try:
                                        response = requests.put(url, headers=headers, data=payload, verify=False)
                                        logger_info("Description added successfully")
                                    except TSC.ServerResponseError as server_err:
                                        logger_error(f"Error publishing {datasource_name}: {server_err}")

                            except TSC.ServerResponseError as server_err:
                                logger_error(f"Error publishing {datasource_name}: {server_err}")
                                datasourcesname.append(datasource_name)
                                migrate.append('Failed to Migrate Datasource')
                                log.append(f"Failed to Migrate Datasource: {server_err}")
                                failed_datasources.append(datasource_name)  # Add failed datasource name to the list
                                total_specific_failed += 1  # Increment counter
                        else:
                            logger_error(f"Project '{destination_path}' does not exist on the cloud server.")
                            logger_error(f"{datasource_name} datasource not published")
                            datasourcesname.append(datasource_name)
                            log.append(f"Project '{destination_path}' does not exist on the cloud server.")
                            migrate.append('Failed to Migrate Datasource')
                            failed_datasources.append(datasource_name)  # Add datasource name to the list
                            total_specific_failed += 1  # Increment counter
        else:
            logger_error(f"Source '{source_path}' project dosen't have any datsource.")

    log_data = pd.DataFrame({
            'Workbook Name': datasourcesname,
            'Log': log,
            'Status': migrate
            })
    file_name='migration_logs.xlsx'
    sheet_name = 'datasource'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = openpyxl.load_workbook(file_path)
    except FileNotFoundError:
        workbook = openpyxl.Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)

    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)

    sheet.append(log_data.columns.tolist())
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
        workbook.save(file_path)

    logger_info("-----End of publishing specific datasources-----")

    if failed_datasources:
        logger_error("Datasources failed to publish:")
        for datasource in failed_datasources:
            logger_error(f"- {datasource}")
            

def main():
    """
    Main executor function
    :return:
    """
    logger_info("::::Starting the migration of datasources::::")
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None, help="Path to the XLSX file.")
    args = parser.parse_args()
    userpath = args.config
    csv_userpath = args.project

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        user_path = os.path.join(os.user_path.expanduser("~"), 'config.xml')
        config = ReaderFactory(user_path).reader().to_json()

    if csv_userpath:
        try:
            path = os.path.join(csv_userpath, 'project_path.xlsx')
            project_mapping=pd.read_excel(path)
            project_mapping_dict = project_mapping.to_dict(orient='records')
            project_mapping_json = json.dumps(project_mapping_dict, indent=4)
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        excel_path = os.path.join(os.excel_path.expanduser("~"), 'project_path.xlsx')
        project_mapping_json = ReaderFactory(excel_path).reader().to_json()
        

    # Parse the JSON string into a list of dictionaries
    csv_data = json.loads(project_mapping_json)

    project_paths = [entry["Source Project_path"] for entry in csv_data if entry.get("Select", "").lower() == "yes"]

    download_path,datasources_Details,description = download(config["credentials"]["server"], project_paths)

    if download_path:
        print(f"Data sources downloaded to: {download_path}")
    else:
        print(f"Failed to download data sources for project: {project_paths}")

    paths = [[entry["Source Project_path"], entry["Destination Project_path"]] for entry in csv_data if entry.get("Select", "").lower() == "yes"]

    with pac_context_for_url('https://prod-useast-b.online.tableau.com/#/site/santanderus/home'):
        tableau_cloud=login_to_tableau(config["credentials"]["cloud"])
        with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
            migrate_datasources(tableau_cloud[0], download_path, paths,datasources_Details,description)


    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f"::::Execution time for migration datasources is: {int(minutes)} min {int(seconds)} sec::::")


if __name__ == "__main__":
    main()
    #delete the temp files:
    for temp_folder in temp_dir_list:
        if os.path.isdir(temp_folder):
            shutil.rmtree(temp_folder)