from logger.logger import *
from datetime import datetime
from openpyxl import styles,Workbook,load_workbook
from connection import get_db_connection,login_to_tableau
from pandas import read_excel,notna,DataFrame
from config_reader.reader_factory import ReaderFactory
from tabulate import tabulate
import requests,time,psycopg2,os,argparse,tableauserverclient as TSC,xml.etree.ElementTree as ET


subscriptions_names = []
log = []
migrate = []
def fetch_schedule_data(connection_cred):
    try:

        connection = get_db_connection(connection_cred)
        if connection is None:
            logger_error("Couldn't connect to database")
            exit(0)
        cursor = connection.cursor()
        # Perform a query to get all data from the 'schedules' table
        table = "schedules"
        query = f"SELECT * FROM {table};"
        cursor.execute(query)
        # Fetch column headers
        col_names = [desc[0] for desc in cursor.description]

        data_dict = {col_name: [] for col_name in col_names}
        rows = cursor.fetchall()
        days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        row_update = [list(row) for row in rows]
        for row in row_update:
            if row[5] is not None:
                mask_int = int(row[5])
                binary_mask = bin(mask_int)[2:][::-1]
                schedule_days = [day for i, day in enumerate(days) if i < len (binary_mask) and binary_mask[i] == '1']
                row[5] = schedule_days
            for i, col_name in enumerate(col_names):
                if isinstance(row[i], datetime):
                    data_dict[col_name].append(row[i].strftime("%Y-%m-%d %H:%M:%S"))
                else:
                    data_dict[col_name].append(row[i])
        return data_dict

        # return connection
    except (Exception, psycopg2.Error) as error:
        print(f"Error while connecting to PostgreSQL: {error}")
        exit(1)

def get_full_project_path( all_projects,project_id):
    # Create a dictionary for quick lookup of projects by their ID
    project_lookup = {project.id: project for project in all_projects}

    path = []
    current_id = project_id

    while current_id:
        project = project_lookup.get(current_id)
        if not project:
            break
        project_name=project.name
        project_name=project_name.replace('/', '_fwd_SLASH_')
        path.append(project_name)

        current_id = project.parent_id

    # Reverse the path to get the full path from root to target project
    full_path = '/'.join(reversed(path))

    return full_path if full_path else None

def get_child_project_id(projects, project_path,server):
    # Base case: If the project path is empty, return None
    if not project_path:
        return None
    for project in projects:
        project_path_ = project_path[0].replace('_fwd_SLASH_', '/')
        if project.name.lower() == project_path_.lower():
            if len(project_path) == 1:
                return project.id
            else:
                child_projects = [p for p in TSC.Pager(server.projects) if p.parent_id == project.id]
                child_project_id = get_child_project_id(child_projects, project_path[1:],server)
                if child_project_id:
                    return child_project_id
    return None

def get_project_ids(path, server):
    all_projects=list(TSC.Pager(server.projects))
    path=path[1:]
    if '/' in path:
        path_parts = path.split('/')
        return get_child_project_id(all_projects, path_parts, server)
    else:
        for pro in all_projects:
            if pro.name.lower() == path.lower() and pro.parent_id is None:
                return pro.id
    return None

def get_subscription_server(server,intervals,project_files):
    """
    Retrieves the subscription server for a Tableau Server instance.
    Args:
        server: A Tableau Server connection object.

    Returns:
        A dictionary containing the subscription server information.
    """

    excel_projects = project_files[project_files['Select'].str.lower() == 'yes'].values.tolist()

    all_views=list(TSC.Pager(server.views))
    all_workbooks=list(TSC.Pager(server.workbooks))
    all_projects = list(TSC.Pager(server.projects))
    server_subscriptions=list(TSC.Pager(server.subscriptions))

    subscription_list=[]
    project_info = None
    workbook_name_view=None
    for subscription in server_subscriptions:
        if subscription.target.type == 'Workbook':
            project_info = next(((wb.project_id, wb.name) for wb in all_workbooks if wb.id == subscription.target.id),(None, None))
        elif subscription.target.type == 'View':
            project_info = next(((v.project_id, v.name) for v in all_views if v.id == subscription.target.id), None)
            if project_info:
                workbook_name_view = next((wb.name for wb in all_workbooks if wb.id == next(
                    v.workbook_id for v in all_views if v.id == subscription.target.id)), None)
        if len(excel_projects)!=0:
            for excel_project in excel_projects:
                project_ids = get_project_ids(excel_project[0], server)
                if project_ids == project_info[0]:
                    get_subscription_list(server,all_projects,subscription,intervals,project_info,workbook_name_view,subscription_list)
        else:
            get_subscription_list(server, all_projects, subscription, intervals, project_info, workbook_name_view, subscription_list)

    return subscription_list

def get_subscription_list(server,all_projects,subscription,intervals,project_info,workbook_name_view,subscription_list):

    users=list(TSC.Pager(server.users))
    end_time=None
    hours=None

    schedule_item = server.schedules.get_by_id(subscription.schedule_id)
    Monthday = schedule_item.interval_item.interval
    next_run_at = schedule_item.next_run_at
    # utc_offset = next_run_at.tzinfo.utcoffset(next_run_at)
    start_time = str(schedule_item.interval_item.start_time) if hasattr(schedule_item.interval_item,'start_time') else "N/A"
    user_email = next((user.email for user in users if user.id == subscription.user_id), None)
    project_path = f"/{get_full_project_path(all_projects,project_info[0])}"
    for interval in intervals:
        for schedule_id, values in interval.items():
            if schedule_item.id == schedule_id:
                frequency, end_time, minutes = values
                if end_time is not None:
                    hours = int(end_time // 60)
                    remaining_minutes = int(end_time % 60)
                    end_time = f"{hours:02}:{remaining_minutes:02}:00"
                if minutes is not None:
                    hours = int(minutes // 60)
    subscription_list.append({
        'subject': subscription.subject, 'message': subscription.message,
        'page_orientation': subscription.page_orientation, 'page_size_option': subscription.page_size_option,
        'send_if_view_empty': subscription.send_if_view_empty, 'user_id': user_email,
        'target_type': subscription.target.type, 'target_path': project_path, 'target_name': project_info[1],
        'frequency': schedule_item.interval_item._frequency, 'interval': frequency, 'start_time': start_time,
        'end_time': end_time, 'attach_image': subscription.attach_image, 'attach_pdf': subscription.attach_pdf,
        'hours': hours, 'workbook_name_view': workbook_name_view, 'Monthday': Monthday, 'next_run_at': next_run_at
    })

def migrate_subscription(cloud_server,subscription_list,project_list,user_list):


    all_workbooks=list(TSC.Pager(cloud_server.workbooks))
    all_views=list(TSC.Pager(cloud_server.views))

    user_cloud=list(TSC.Pager(cloud_server.users))

    for sub in subscription_list:
        for filter_project in project_list:
            if sub['target_path'] == filter_project[0] and notna(filter_project[1]):
                sub['target_path']=filter_project[1]
                break
        for filter_user in user_list:
            if sub['user_id']==filter_user[0]:
                user_id=next((user.id for user in user_cloud if user.email == filter_user[2]),None)
                if user_id is not None:
                    sub['user_id'] = user_id
                else:
                    sub['user_id'] = user_id
                    logger_error(f"Could not find the user [{filter_user[2]}] ")
                    subscriptions_names.append(sub['subject'])
                    log.append(f"Could not find the user [{filter_user[2]}]")
                    migrate.append('Failed to Migrate Subscription')
                break

    valid_subscriptions = []

    for sub in subscription_list:
        project_ids = get_project_ids(sub['target_path'], cloud_server)
        if project_ids is None:
            logger_error(f"Could not find the project path [{sub['target_path']}] ")
            subscriptions_names.append(sub['subject'])
            log.append(f"Could not find the project path [{sub['target_path']}]")
            migrate.append('Failed to Migrate Subscription')
        else:
            if sub['target_type'].lower() == 'workbook':
                workbook_found = False
                for workbook in all_workbooks:
                    if workbook.project_id == project_ids and workbook.name == sub['target_name']:
                        sub['target_id'] = workbook.id
                        workbook_found = True
                        valid_subscriptions.append(sub)
                        break
                if not workbook_found:
                    logger_error(f"Could not find the workbook [{sub['target_name']}] in project [{sub['target_path']}]")
                    subscriptions_names.append(sub['subject'])
                    log.append(f"Could not find the view [{sub['target_name']}] in project [{sub['target_path']}]")
                    migrate.append('Failed to Migrate Subscription')

            if sub['target_type'].lower() == 'view':
                view_found = False
                workbook_ids=next((workbook.id for workbook in all_workbooks if workbook.project_id==project_ids and workbook.name == sub['workbook_name_view']),None)
                if workbook_ids is not None:
                    for view in all_views:
                        if view.project_id==project_ids and view.name==sub['target_name'] and view.workbook_id==workbook_ids:
                            sub['target_id'] = view.id
                            view_found = True
                            valid_subscriptions.append(sub)
                            break
                    if not view_found:
                        logger_error(f"Could not find the view [{sub['target_name']}] in project [{sub['target_path']}]")
                        subscriptions_names.append(sub['subject'])
                        log.append(f"Could not find the view [{sub['target_name']}] in project [{sub['target_path']}]")
                        migrate.append('Failed to Migrate Subscription')
                else:
                    logger_error(f"Could not find the workbook [{sub['target_name']}] in project [{sub['target_path']}]")


    # Replace the original subscription_list with the valid subscriptions
    subscription_list = valid_subscriptions
    for sub in subscription_list:
        if sub['user_id'] is not None:
            request_xml(sub,cloud_server)


def request_xml(sub,cloud_server):
    global subscriptions_names
    global log
    global migrate

    headers = {"Content-Type": "application/xml", "Accept": "application/json",
               "X-Tableau-Auth": cloud_server.auth_token}
    url=f'{cloud_server.baseurl}/sites/{cloud_server.site_id}/subscriptions'
    request = ET.Element("tsRequest")
    subscription = ET.SubElement(request, "subscription",subject=sub['subject'],attachImage=str(sub['attach_image']).lower(),attachPdf=str(sub['attach_pdf']).lower())
    if sub['message'] is not None:
        subscription.set('message', sub['message'])
    if sub['page_orientation'] is not None:
        subscription.set('pageOrientation', str(sub['page_orientation']).lower())
    if sub['page_size_option'] is not None:
        subscription.set('pageSizeOption', sub['page_size_option'])
    ET.SubElement(subscription,"content",id=sub['target_id'],type=sub['target_type'],sendIfViewEmpty=str(sub['send_if_view_empty']).lower())
    ET.SubElement(subscription,"user",id=sub['user_id'])
    schedule= ET.SubElement(request,"schedule",frequency=sub['frequency'],nextRunAt=f"{sub['next_run_at']}")
    if sub['frequency'] == "Daily":
        frequencyDetails = ET.SubElement(schedule, "frequencyDetails")
        if sub['start_time'] is not None:
            frequencyDetails.set('start', sub['start_time'])
        if sub['end_time'] is not None:
            frequencyDetails.set('end', sub['end_time'])
        intervals = ET.SubElement(frequencyDetails, "intervals")
        if sub['hours'] is not None:
            ET.SubElement(intervals,'interval',hours=f"{sub['hours']}")
        if sub['interval'] is not None:
            for days in sub['interval']:
                ET.SubElement(intervals,'interval',weekDay=days)
    if sub['frequency']=='Hourly':
        frequencyDetails = ET.SubElement(schedule, "frequencyDetails", start=sub['start_time'], end=sub['end_time'])
        intervals = ET.SubElement(frequencyDetails, "intervals")
        if sub['hours'] is not None:
            ET.SubElement(intervals,'interval',hours=f"{sub['hours']}")
        for days in sub['interval']:
            ET.SubElement(intervals,'interval',weekDay=days)
    if sub['frequency']=='Monthly':
        frequencyDetails = ET.SubElement(schedule, "frequencyDetails", start=sub['start_time'])
        intervals = ET.SubElement(frequencyDetails, "intervals")
        for day in sub['Monthday']:
            if sub['interval'] is not None:
                for days in sub['interval']:
                    ET.SubElement(intervals, 'interval', monthDay=day,weekDay=days)
            else:
                ET.SubElement(intervals, 'interval', monthDay=day)
    if sub['frequency']=='Weekly':
        frequencyDetails = ET.SubElement(schedule, "frequencyDetails", start=sub['start_time'])
        intervals = ET.SubElement(frequencyDetails, "intervals")
        for days in sub['interval']:
            ET.SubElement(intervals, 'interval', weekDay=days)
    try:
        response = requests.post(url, headers=headers, data=ET.tostring(request, encoding="unicode"), timeout=45)
        responses=response.json()
        if response.status_code == 201:
            logger_info(f"Subscription migrated successfully: {sub['subject']}")
            subscriptions_names.append(sub['subject'])
            log.append(f"Subscription migrated successfully")
            migrate.append('Migrated Subscription')
        else:
            logger_error(f"Failed to Migrate Subscription:\t{responses['error']['detail']}")
            subscriptions_names.append(sub['subject'])
            log.append(responses['error']['detail'])
            migrate.append('Failed to Migrate Subscription')

    except TSC.ServerResponseError as server_err:
        subscriptions_names.append(sub['subject'])
        log.append(server_err)
        migrate.append('Failed to Migrate Subscription')
        logger_error(f"Failed to Migrate Subscription: {server_err}")

def download(server_filters,project_files):
    data = fetch_schedule_data(server_filters['credentials']['database'])
    intervals = [{luid: (day, end,minute)} for luid,minute,day, end in zip(data["luid"],data['minute_interval'], data["day_of_week_mask"], data["end_at_minute"])]

    tableau_server=login_to_tableau(server_filters["credentials"]['server'])
    with tableau_server[0].auth.sign_in(tableau_server[1]):
        return get_subscription_server(tableau_server[0],intervals,project_files)

def main():
    """
    Main executor function
    :return:
    """
    logger_info("Starting the Subscription Migration")
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None,help="Path to the .xlsx file containing project data.")
    parser.add_argument("--user", type=str, default=None, help="Path to the .xlsx file containing user data.")
    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project
    excel_user = args.user

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config_file = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a config file path")

    if excel_project:
        try:
            path = os.path.join(excel_project, 'project_path.xlsx')
            project_file = read_excel(path)
        except FileNotFoundError as e:
            logger_error(f"The specified project mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a Project Mapping file path")

    if excel_user:
        try:
            path_u = os.path.join(excel_user, 'user_mapping.xlsx')
            user_file = read_excel(path_u,sheet_name='Users')
        except FileNotFoundError as e:
            logger_error(f"The specified user mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a User Mapping file path")
    #Login to tableau server
    dist= download(config_file,project_file)

    print("\n\nSubscriptions :::")
    details_data = [[d['target_name'], d['user_id'], d['target_type']] for d in dist]
    details_headers = ["Target Type ", "User Email", "Target Type"]
    print(Fore.CYAN + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    #Login to tableau cloud
    tableau_cloud = login_to_tableau(config_file["credentials"]['cloud'])
    with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
            migrate_subscription(tableau_cloud[0],dist,project_file.values.tolist(),user_file.values.tolist())
    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f"::::Execution time for migrating Project Owner is: {int(minutes)} min {int(seconds)} sec::::")

    log_data = DataFrame({
        'Subscription Name': subscriptions_names,
        'Log': log,
        'Status': migrate
    })

    file_name='migration_logs.xlsx'
    sheet_name = 'subscription'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = load_workbook(file_path)
    except FileNotFoundError:
        workbook = Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)

    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)
    sheet.append(log_data.columns.tolist())
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
    for cell in sheet[1]:
        cell.font = styles.Font(bold=True)
    workbook.save(file_path)

    logger_info(f"::::Migration log file generated : {file_path}::::")
    print(Fore.YELLOW + '\n\t\t\t---------------------- END OF SUBSCRIPTION MIGRATION ----------------------' + Style.RESET_ALL)


if __name__ == "__main__":
    main()