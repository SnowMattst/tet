from pandas import DataFrame
from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from tableauserverclient import Pager,NotSignedInError
from connection import login_to_tableau

import argparse,os

def create_excel_csv(filename,config):
    tableau_server=login_to_tableau(config['credentials']['server'])
    with tableau_server[0].auth.sign_in(tableau_server[1]):
        all_projects=list(Pager(tableau_server[0].projects))
        project_paths = sorted([get_full_project_path(all_projects, project.id) for project in all_projects])
        # Create a dataframe from the user emails
        df = DataFrame({
            'Source Project_path': project_paths,
            'Destination Project_path': ['' for _ in range(len(project_paths))],
            'Select': ['no' for _ in range(len(project_paths))],
        })
        df.to_excel(filename, index=False)
        return filename
def get_full_project_path( all_projects,project_id):
    # Create a dictionary for quick lookup of projects by their ID
    project_lookup = {project.id: project for project in all_projects}

    path = []
    current_id = project_id

    while current_id:
        project = project_lookup.get(current_id)
        if not project:
            break
        project_name=project.name
        project_name=project_name.replace('/', '_fwd_SLASH_')
        path.append(project_name)
        current_id = project.parent_id
    # Reverse the path to get the full path from root to target project
    full_path = '/'.join(reversed(path))
    # Ensure the path starts with a '/'
    if not full_path.startswith('/'):
        full_path = '/' + full_path
    return full_path if full_path else 'Top-level-project'

def main():
    """
    Main executor function
    :return:
    """
    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")

    args = parser.parse_args()
    userpath = args.config

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        try:
            path = os.path.join(os.path.expanduser("~"), 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    # File name for the Excel file
    filename = 'project_path.xlsx'
    try:
        file_path = create_excel_csv(filename,config)
        logger_info(f"File created at: {file_path}")

    except PermissionError:
        logger_error("Permission error occurred during file creation.")

    except FileNotFoundError:
        logger_error("File not found error occurred during file creation.")

    except NotSignedInError as e:
        logger_error(f"An tabeau signin error occurred during file creation : \n\n{e}")
    except Exception as e:
        logger_error(f"An unexpected error occurred during file creation: \n\n{e}")

if __name__ == "__main__":
    main()

