import argparse
import os

import pandas as pd
import tableauserverclient as TSC
from tableauserverclient import *

from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from connection import login_to_tableau,get_all_items

def get_full_project_path(all_projects, project_id):
    project_lookup = {project.id: project for project in all_projects}
    path = []
    current_id = project_id

    while current_id:
        project = project_lookup.get(current_id)
        if not project:
            break
        path.append(project.name)
        current_id = project.parent_id

    full_path = '/'.join(reversed(path))
    if not full_path.startswith('/'):
        full_path = '/' + full_path

    return full_path if full_path else 'Top-level-project'

def retrieve_datasources(tableau_server):
    all_projects = get_all_items(tableau_server,'project')
    datasources = get_all_items(tableau_server,'datasource')

    data = []
    for datasource in datasources:
        project_path = get_full_project_path(all_projects, datasource.project_id)
        data.append({
            'Id': datasource.id,
            'Name': datasource.name,
            'Type': datasource.datasource_type,
            'Project_Id': datasource.project_id,
            'Project_Name': datasource.project_name,
            'Src_Content_Url': datasource.content_url,
            'Project_Path': project_path,
            'destination_datasource_id': '',
            'destination_content_url': ''
        })

    return pd.DataFrame(data)

def create_datasource_excel(filename,config,project_mapping):

    tableau_server=login_to_tableau(config['credentials']['server'])
    all_server_datasources=[]
    with tableau_server[0].auth.sign_in(tableau_server[1]):
        server_datasources = retrieve_datasources(tableau_server[0])
        all_server_datasources.append(server_datasources)

    tableau_cloud=login_to_tableau(config['credentials']['cloud'])
    all_cloud_datasources=[]
    with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
        cloud_datasources = retrieve_datasources(tableau_cloud[0])
        all_cloud_datasources.append(cloud_datasources)

    all_server_datasources_df = pd.concat(all_server_datasources, ignore_index=True)
    all_cloud_datasources_df = pd.concat(all_cloud_datasources, ignore_index=True)

    merged_data = []
    for _, server_ds in all_server_datasources_df.iterrows():
        source_path = server_ds['Project_Path']
        matched_rows = project_mapping[project_mapping['Source Project_path'] == source_path]
        if not matched_rows.empty:
            for _, matched_row in matched_rows.iterrows():
                destination_path = matched_row['Destination Project_path']
                matched_cloud_ds = all_cloud_datasources_df[
                    (all_cloud_datasources_df['Project_Path'] == destination_path) &
                    (all_cloud_datasources_df['Name'] == server_ds['Name'])
                ]

                if not matched_cloud_ds.empty:
                    for _, cloud_ds in matched_cloud_ds.iterrows():
                        merged_data.append({
                            'Server_Id': server_ds['Id'],
                            'Server_Name': server_ds['Name'],
                            'Server_Type': server_ds['Type'],
                            'Server_Project_Id': server_ds['Project_Id'],
                            'Server_Project_Name': server_ds['Project_Name'],
                            'Server_Src_Content_Url': server_ds['Src_Content_Url'],
                            'Server_Project_Path': server_ds['Project_Path'],
                            'Cloud_Id': cloud_ds['Id'],
                            'Cloud_Name': cloud_ds['Name'],
                            'Cloud_Type': cloud_ds['Type'],
                            'Cloud_Project_Id': cloud_ds['Project_Id'],
                            'Cloud_Project_Name': cloud_ds['Project_Name'],
                            'Cloud_Src_Content_Url': cloud_ds['Src_Content_Url'],
                            'Cloud_Project_Path': cloud_ds['Project_Path']
                        })
                else:
                    merged_data.append({
                        'Server_Id': server_ds['Id'],
                        'Server_Name': server_ds['Name'],
                        'Server_Type': server_ds['Type'],
                        'Server_Project_Id': server_ds['Project_Id'],
                        'Server_Project_Name': server_ds['Project_Name'],
                        'Server_Src_Content_Url': server_ds['Src_Content_Url'],
                        'Server_Project_Path': server_ds['Project_Path'],
                        'Cloud_Id': '',
                        'Cloud_Name': '',
                        'Cloud_Type': '',
                        'Cloud_Project_Id': '',
                        'Cloud_Project_Name': '',
                        'Cloud_Src_Content_Url': '',
                        'Cloud_Project_Path': ''
                    })
        else:
            merged_data.append({
                'Server_Id': server_ds['Id'],
                'Server_Name': server_ds['Name'],
                'Server_Type': server_ds['Type'],
                'Server_Project_Id': server_ds['Project_Id'],
                'Server_Project_Name': server_ds['Project_Name'],
                'Server_Src_Content_Url': server_ds['Src_Content_Url'],
                'Server_Project_Path': server_ds['Project_Path'],
                'Cloud_Id': '',
                'Cloud_Name': '',
                'Cloud_Type': '',
                'Cloud_Project_Id': '',
                'Cloud_Project_Name': '',
                'Cloud_Src_Content_Url': '',
                'Cloud_Project_Path': ''
            })

    merged_df = pd.DataFrame(merged_data)

    file_path = os.path.abspath(filename)
    writer = pd.ExcelWriter(file_path, engine='xlsxwriter')
    merged_df.to_excel(writer, sheet_name='MergedData', index=False)
    writer.close()

    logger_info(f"Excel file '{file_path}' with data created successfully.")
    return file_path

def main():
    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the directory containing the XML file.")
    parser.add_argument("--project", type=str, required=True, help="Path to the Excel file containing project mappings.")
    args = parser.parse_args()
    userpath = args.config
    project_mapping_path = args.project

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        user_path = os.path.join(os.user_path.expanduser("~"), 'config.xml')
        config = ReaderFactory(user_path).reader().to_json()

    try:
        project_mapping_path = os.path.join(project_mapping_path, 'project_path.xlsx')
        project_mapping = pd.read_excel(project_mapping_path)
    except FileNotFoundError:
        logger_error(f"The project mapping file does not exist at: {project_mapping_path}")
        exit(1)
    except Exception as e:
        logger_error(f"An error occurred while reading the project mapping file: {e}")
        exit(1)

    filename = 'datasource_path.xlsx'

    try:
        file_path = create_datasource_excel(filename, config,project_mapping)
        logger_info(f"File created at: {file_path}")

    except PermissionError:
        logger_error("Permission error occurred during file creation.")

    except FileNotFoundError:
        logger_error("File not found error occurred during file creation.")

    except Exception as e:
        logger_error(f"An unexpected error occurred during file creation: {e}")

if __name__ == "__main__":
    main()
