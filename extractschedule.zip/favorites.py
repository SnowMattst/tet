from openpyxl.styles import Font
from openpyxl import Workbook,load_workbook
from pandas import notna,read_excel,DataFrame
from tableauserverclient import ServerResponseError
from tabulate import tabulate
from connection import login_to_tableau,get_all_items,get_project_ids,get_full_project_path
from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from pypac import pac_context_for_url

import requests,os,time,argparse,html

entity_name=[]
log=[]
status=[]

def get_specific_user(server,project_files,user_files):
    """
    Get favorites for specific users from the server
    :param server: The Tableau server object
    :return: A dictionary mapping user emails to their favorites
    """

    user_favorite_map = {}
    all_users=get_all_items(server, 'user')
    all_projects=get_all_items(server,'project')
    excel_projects=project_files[project_files['Select'].str.lower() == 'yes'].values.tolist()
    for user_file in user_files.values.tolist():
        user=next((users for users in all_users if users.email==user_file[0]),None)
        if user is not None:
            logger_info(f"Getting favorites for the user: {user.name}")
            server.favorites.get(user)
            favorites=user.favorites
            if len(excel_projects)==0:
                fav_list=[]
                for type, favorite in favorites.items():
                    for fav in favorite:
                        if type != 'projects':
                            project_id = fav.project_id
                        else:
                            project_id = fav.parent_id or fav.id
                        project_path = f"/{get_full_project_path(all_projects, project_id)}"
                        for project in project_files.values.tolist():
                            if project[0] == project_path and notna(project[1]):
                                project_path = project[1]
                                break
                        fav_list.append((fav.name, fav.name, project_path, type))
                user_favorite_map[user_file[2]]=fav_list
            else:
                fav_list = []
                for project in excel_projects:
                    project_ids = get_project_ids(project[0], server)
                    project_path = project[0]
                    for type, favorite in favorites.items():
                        for fav in favorite:
                            # Determine if the favorite matches the project IDs
                            if (type != "projects" and fav.project_id == project_ids) or \
                                    (type == "projects" and fav.parent_id == project_ids):
                                full_project_path = f"/{get_full_project_path(all_projects, fav.project_id if type != 'projects' else (fav.parent_id or fav.id))}"
                                if project_path == full_project_path and notna(project[1]):
                                    project_path = project[1]
                                fav_list.append((fav.name, fav.name, project_path, type))
                            if type=='projects' and fav.id == project_ids:
                                fav_list.append((fav.name, fav.name, project_path, 'Main project'))

                user_favorite_map[user_file[2]] = fav_list
            headers = ['Label', 'Name', 'Project Path', 'Type']
            print(Fore.CYAN + tabulate(fav_list, headers=headers, tablefmt='grid') + Style.RESET_ALL)
        else:
            logger_error(f'User with Email: {user_file[0]} Not Found on server')
            entity_name.append(f"User:{user_file[0]}")
            log.append("User not found on server")
            status.append('Not Migrated')

    if len(user_favorite_map)>0:
        return user_favorite_map
    else:
        logger_error('No Users Found')
        entity_name.append("No Users Found")
        log.append("No Users Found")
        status.append('Not Migrated')
def migrated_favorites(cloud_server, user,favorites):
    all_datasources=get_all_items(cloud_server,'datasource')
    all_workbooks=get_all_items(cloud_server,'workbook')
    all_views=get_all_items(cloud_server,'view')
    all_flows=get_all_items(cloud_server,'flow')
    all_projects=get_all_items(cloud_server,'project')

    for fav in favorites:
        fav=list(fav)
        project_ids = get_project_ids(fav[2], cloud_server)
        entity_id = None
        if project_ids:
            if fav[3] == 'datasources':
                for datasource in all_datasources:
                    if datasource.name == fav[1] and datasource.project_id in project_ids:
                        entity_id = datasource.id
                        break
            elif fav[3] == 'workbooks':
                for workbook in all_workbooks:
                    if workbook.name == fav[1] and workbook.project_id in project_ids:
                        entity_id = workbook.id
                        break
            elif fav[3]=='views':
                for view in all_views:
                    if view.name == fav[1] and view.project_id in project_ids:
                        entity_id = view.id
                        break
            elif fav[3]=='flows':
                for flow in all_flows:
                    if flow.name == fav[1] and flow.project_id in project_ids:
                        entity_id = flow.id
                        break
            elif fav[3]=='projects':
                for project in all_projects:
                    if project.name ==fav[1] and project.parent_id==project_ids:
                        entity_id = project.id
                        break
            elif fav[3]=='Main project':
                for project in all_projects:
                    if project.name == fav[1] and project.id==project_ids:
                        entity_id = project.id
                        fav[3] ='projects'
                        break

            if entity_id is not None:
                xml_request(cloud_server,fav,user,entity_id)
            else:
                logger_error(f"{fav[3]}:{fav[1]} Not found in project path:{fav[2]}")
                entity_name.append(f"{fav[3]}:{fav[1]} Path:{fav[2]}")
                log.append(f"{fav[3]}:{fav[1]} Not found in project path:{fav[2]} for user :{user.email}")
                status.append('Not Migrated')
        else:
            logger_error(f"Project path:{fav[2]} not found in cloud")
            entity_name.append(f"Project Path:{fav[2]}")
            log.append(f"Project path:{fav[2]} not found in cloud for user :{user.email}")
            status.append('Not Migrated')
def add_fav_to_user(cloud_server,user_list):
    all_users =get_all_items(cloud_server,'user')
    for user_email,favorites in user_list.items():
        user = next((user for user in all_users if user.email==user_email),None)
        if user:
            logger_info(Fore.YELLOW+f"Migrating favorites for user:{user_email}"+Style.RESET_ALL)
            migrated_favorites(cloud_server,user,favorites)
        else:
            logger_error(f"User:{user_email} not found in cloud ")
            entity_name.append(f"User :{user_email}")
            log.append(f"User:{user_email} not found in cloud")
            status.append("Not Migrated")
def xml_request(cloud_server,favorite,user,entity_id):
    label = html.escape(favorite[0], quote=True)
    xml_body = f"""
    <tsRequest>
    <favorite label="{label}" >
        <{favorite[3][:-1]} id="{entity_id}" />
    </favorite>
    </tsRequest>
    """
    try:
        url=f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/favorites/{user.id}"
        headers = {"Content-Type": "application/xml", "X-Tableau-Auth": cloud_server.auth_token}
        response = requests.put(url, headers=headers, data=xml_body,verify=False)
        if response.status_code == 200:
            logger_info(f"{favorite[3][:-1]}:'{favorite[1]}' Successfully added to favorites for the user:{user.email}")
            entity_name.append(f"{favorite[3][:-1]}:'{favorite[1]}' Path:{favorite[2]}")
            log.append(f"{favorite[3][:-1]}:'{favorite[1]}' Successfully added to favorites for the user:{user.email}")
            status.append('Migrated')
        else:
            logger_error(f"Error migrating favorites for user {user.email} ::::{response.status_code} -{response.text}")
            entity_name.append(f"User:{user.email},{favorite[3][:-1]}:'{favorite[1]}',Path:{favorite[2]}")
            log.append(f"Error migrating favorites for user {user.email} ::::{response.status_code} - {response.text}")
            status.append('Not Migrated')
    except ServerResponseError as error:
        logger_error(f"Error migrating favorites for user {user.email} ::::{error}")
        entity_name.append(f"User:{user.email},{favorite[3][:-1]}:'{favorite[1]}',Path:{favorite[2]}")
        log.append(f"Error migrating favorites for user {user.email} ::::{error}")
        status.append('Not Migrated')
    except Exception as e:
        logger_error(f"Error migrating favorites for user {user.email} ::::{e}")
        entity_name.append(f"User:{user.email},{favorite[3][:-1]}:'{favorite[1]}',Path:{favorite[2]}")
        log.append(f"Error migrating favorites for user {user.email} ::::{e}")
        status.append('Not Migrated')
def main():
    """
    Main executor function to migrate favorites
    """
    logger_info(":::: Starting the migration of favorites ::::")
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None,help="Path to the .xlsx file containing project data.")
    parser.add_argument("--user", type=str, default=None, help="Path to the .xlsx file containing user data.")
    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project
    excel_user = args.user

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config_file = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a config file path")

    if excel_project:
        try:
            path = os.path.join(excel_project, 'project_path.xlsx')
            project_file = read_excel(path)
        except FileNotFoundError as e:
            logger_error(f"The specified project mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a Project Mapping file path")

    if excel_user:
        try:
            path_u = os.path.join(excel_user, 'user_mapping.xlsx')
            user_file = read_excel(path_u,sheet_name='Users')
        except FileNotFoundError as e:
            logger_error(f"The specified user mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a User Mapping file path")

    #Login to Tableau Server
    with pac_context_for_url('https://srvtblupwvsu201.shusapro.santanderholdingsusa.corp'):
        tableau_server=login_to_tableau(config_file["credentials"]['server'])
        with tableau_server[0].auth.sign_in(tableau_server[1]):
            dist_list=get_specific_user(tableau_server[0], project_file, user_file)

    # Login to Tableau Cloud
    with pac_context_for_url('https://srvtblupwvsu201.shusapro.santanderholdingsusa.corp'):
        tableau_cloud=login_to_tableau(config_file["credentials"]['cloud'])
        with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
                add_fav_to_user(tableau_cloud[0],dist_list)

    log_data = DataFrame({
        'Entity Name': entity_name,
        'Log': log,
        'Status': status
    })

    file_name='migration_logs.xlsx'
    sheet_name = 'Favorites'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = load_workbook(file_path)
    except FileNotFoundError:
        workbook =Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)

    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)
    sheet.append(log_data.columns.tolist())
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
    workbook.save(file_path)

    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f"::::Execution time for migrating favorites is: {int(minutes)} min {int(seconds)} sec::::")
    logger_info(f"::::Migration log file generated : {file_path}::::")

    print(Fore.YELLOW + '\n\t\t\t---------------------- END OF FAVORITES OWNER MIGRATION ----------------------' + Style.RESET_ALL)



if __name__ == "__main__":
    main()
