from config_reader.reader_factory import ReaderFactory
from pandas import notna,read_excel,DataFrame
from tableauserverclient import *
from logger.logger import *
from openpyxl.styles import Font

import zipfile,shutil,openpyxl,os,urllib.parse,argparse
import requests,time,tableauserverclient as TSC,xml.etree.ElementTree as ET

workbook_names = []
log = []
migrate = []

def get_all_items(server, item):
    items = {
        'project': server.projects,
        'workbook': server.workbooks,
        'datasource': server.datasources,
        'view': server.views,
        'flow': server.flows,
        'user': server.users,
        'group': server.groups
    }
    if item in items:
        return list(TSC.Pager(items[item]))

def get_child_project_id(projects, project_path, server):
    if not project_path:
        return None

    for project in projects:
        # Check if the current project name matches the first part of the project path
        if project.name == project_path[0]:
            # It's the last part of the path, return the project ID
            if len(project_path) == 1:
                return project.id
            # Otherwise, recursively search for the child project ID
            else:
                child_projects = [p for p in TSC.Pager(server.projects) if p.parent_id == project.id]
                try:
                    child_project_id = get_child_project_id(child_projects, project_path[1:], server)
                    if child_project_id:
                        return child_project_id
                except (IndexError, AttributeError) as e:
                    logger_error(f"Error: {e}")
                    return None

    # If no matching project is found, return None
    return None
def create_twbx(folder_path, output_path):
    try:
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(folder_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arc_name = os.path.relpath(file_path, folder_path)
                    zf.write(file_path, arc_name)
    except zipfile.BadZipfile as e:
        print(f"Error creating zip file: {e}")
    except OSError as e:
        print(f"Error accessing files or writing zip file: {e}")
def get_project_ids(path, server):
    path=path[1:]
    if '/' in path:
        path_parts = path.split('/')
        return get_child_project_id(TSC.Pager(server.projects), path_parts, server)
    else:
        for pro in TSC.Pager(server.projects):
            if pro.name == path and pro.parent_id is None:
                return pro.id

def get_action_url_workbooks(server,project_file):
    headers = {"Content-Type": "application/xml", "Accept": "application/json",
               "X-Tableau-Auth": server.auth_token}
    all_workbooks = get_all_items(server,'workbook')

    workbook_ids = {}
    for project_name in project_file:
        project_path = project_name[1] if notna(project_name[1]) else project_name[0]
        project_id = get_project_ids(project_path, server)
        if project_id:
            for wb in all_workbooks:
                if wb.project_id == project_id:
                    workbook_ids[wb.name] = wb.id
        else:
            workbook_names.append(f'Project name :{project_name} not found')
            log.append('Failed to Migrate Workbook')
            migrate.append('Not migrated')
            logger_error(f"Project {project_name} not found.")

    folder = os.path.join(os.getcwd(), 'workbook')
    if not os.path.exists(folder):
        os.makedirs(folder)

    if workbook_ids:
        for wb_name, wb_id in workbook_ids.items():
            logger_info(f"Downloading workbook: {wb_name} for Cloud")
            wb_name=urllib.parse.quote(wb_name)
            file_path = os.path.join(folder, f"{wb_id}_{wb_name}.twbx")
            try:
                url = f"{server.baseurl}/sites/{server.site_id}/workbooks/{wb_id}/content"
                response = requests.get(url, headers=headers)
                response.raise_for_status()

                if response.headers.get('Content-Type') == 'application/xml':
                    root = ET.fromstring(response.content)
                    action_nodes = root.findall(f".//action")
                    if action_nodes:
                        with open(file_path, "wb") as file:
                            file.write(response.content)
                    else:
                        workbook_names.append(f'Workbook:{wb_name} Does not have Action URL')
                        log.append('No action URLs found in the workbook.')
                        migrate.append('Not migrated')
                        logger_info("No action URLs found in the workbook.")
                else:
                    with open(file_path, "wb") as file:
                        file.write(response.content)

                    folder_path = os.path.join(folder, f'{wb_id}_{wb_name}')
                    if not os.path.exists(folder_path):
                        os.makedirs(folder_path)

                    with zipfile.ZipFile(file_path, 'r') as zip_ref:
                        zip_ref.extractall(folder_path)

                    twb_file_path = os.path.join(folder_path,
                                                 [f for f in os.listdir(folder_path) if f.endswith('.twb')][0])
                    tree = ET.parse(twb_file_path)
                    root = tree.getroot()
                    action_nodes = root.findall(f".//action")
                    if not action_nodes:
                        shutil.rmtree(folder_path)
                        workbook_names.append(f'Workbook:{wb_name} Does not have Action URL')
                        log.append('No action URLs found in the workbook.')
                        migrate.append('Not migrated')
                        logger_info("No action URLs found in the workbook.")
                    os.remove(file_path)

            except requests.exceptions.RequestException as e:
                workbook_names.append(f'Error downloading workbook:{wb_name}')
                log.append(str(e))
                migrate.append('Not migrated')
                logger_error(f"Error downloading workbook '{wb_name}': {str(e)}")
            except (IOError, Exception) as e:
                workbook_names.append(f'Error saving or processing workbook:{wb_name}')
                log.append(str(e))
                migrate.append('Not migrated')
                logger_error(f"Error saving or processing workbook '{wb_name}': {str(e)}")
    else:
        workbook_names.append(f'No Workbook in selected projects')
        log.append('Project without workbook')
        migrate.append('Not migrated')
        logger_error("No workbooks found for migration.")

def open_matching_workbooks(source_server,cloud_server,server_site_name,cloud_site_name):
    folder = os.path.join(os.getcwd(), 'workbook')
    for file in os.listdir(folder):
        logger_info(Fore.CYAN+f"Updating Workbook: {urllib.parse.unquote(file.split('_',1)[1])}"+ Style.RESET_ALL)
        file_path = os.path.join(folder, file)
        if os.path.exists(file_path):
            if os.path.isfile(file_path):
                process_cloud_file(file_path,file,server_site_name,cloud_server,source_server,cloud_site_name,'no')
            if os.path.isdir(file_path):
                twb_file = [file for file in os.listdir(file_path) if file.endswith('.twb')]
                main_path=os.path.join(file_path,twb_file[0])
                process_cloud_file(main_path,file,server_site_name,cloud_server,source_server,cloud_site_name,'yes')

def process_cloud_file(file_path,file,server_site_name,cloud_server,source_server,cloud_site_name,item):
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        action_nodes = root.findall(".//action")
        for action_node in action_nodes:
            link_nodes = action_node.findall("./link")
            for each_link in link_nodes:
                logger_info(f"Updating link: {each_link.get('expression')}")
                if f"{server_site_name}/views" in each_link.get('expression'):
                    update_view_link(each_link,cloud_server,source_server,cloud_site_name,tree,file_path,file,item)
                if f"{server_site_name}/workbooks" in each_link.get('expression'):
                    update_workbook_link(each_link,cloud_server,source_server,tree,file_path,file,item)
                # if f"{server_site_name}/datasources" in each_link.get('expression'):
                #     update_datasource_link(each_link,cloud_server,cloud_site_name,file_path)
                # if f"{server_site_name}/flows" in each_link.get('expression'):
                #     update_flow_link(each_link,cloud_server,cloud_site_name,file_path)
                # if f"{server_site_name}/projects" in each_link.get('expression'):
                #     update_project_link(each_link,cloud_server,cloud_site_name,file_path)
                else:
                    workbook_names.append(f"Url : {each_link.get('expression')} Already Updated")
                    log.append("")
                    migrate.append("Not migrated")
                    logger_info(f"::: Url : {each_link.get('expression')} Already Updated")
    except ET.ParseError as e:
        logger_error(f"Error parsing {file_path}: {e}")
def update_view_link(each_link,cloud_server,source_server,cloud_site_name,tree,file_path,file,item):
    expression = each_link.get('expression')

    user_input = input("Provide the correct project path for views: ")
    # user_input='/100 Workbooks'
    workbook_name=None
    expression = expression.rsplit('?', 1)
    expression=expression[0].split('/')
    expression="/".join(expression[-2:])
    all_views = get_all_items(source_server, 'view')
    project_ids= get_project_ids(user_input, cloud_server)
    if project_ids:
        for view in all_views:
                view_url=view.content_url.split('/')
                view_url='/'.join([view_url[0], view_url[2]])
                if view_url==expression:
                    all_workbooks = get_all_items(source_server, 'workbook')
                    workbook_name=next((workbook.name for workbook in all_workbooks if workbook.id==view.workbook_id),None)
                    break
        if workbook_name:
            all_workbooks=get_all_items(cloud_server,'workbook')
            workbook_ids=next((workbook.id for workbook in all_workbooks if workbook.name==workbook_name and workbook.project_id==project_ids),None)
            if workbook_ids:
                all_views=get_all_items(cloud_server,'view')
                view_name = expression.split('/')[-1]
                view_content_url=next((view.content_url for view in all_views if view.name.replace(" ", "") ==view_name and view.workbook_id==workbook_ids),None)
                if view_content_url:
                    view_url=view_content_url.split('/')
                    new_expression = f"/#/site/{cloud_site_name}/views/{view_url[0]}/{view_url[2]}"
                    each_link.set('expression', new_expression)
                    tree.write(file_path, encoding="utf-8", xml_declaration=True)
                    logger_info("Successfully Updated the URL Of View")
                    workbook_names.append(f"Workbook :{urllib.parse.unquote(file.split('_',1)[1].split('.twbx')[0])} Url Updated successfully")
                    log.append("Successfully Updated the URL Of View")
                    migrate.append('Migrated')
                else:
                    logger_error(f"View '{view_name}' not found in workbook '{workbook_name}'.")
                    workbook_names.append(f"Workbook :{urllib.parse.unquote(file.split('_',1)[1].split('.twbx')[0])} Url Updated successfully")
                    log.append(f"View '{view_name}' not found in workbook '{workbook_name}'.")
                    migrate.append('Not Migrated')
        else:
            logger_error(f"Workbook '{workbook_name}' not found in the project path:{user_input}")
            workbook_names.append(f"Workbook :{urllib.parse.unquote(file.split('_', 1)[1].split('.twbx')[0])}")
            log.append(f"Workbook '{workbook_name}' not found. in the project Path:{user_input}")
            migrate.append('Not Migrated')
    else:
        logger_error(f"Project path: {user_input} does not exist")
        workbook_names.append(f"Workbook :{urllib.parse.unquote(file.split('_', 1)[1].split('.twbx')[0])}")
        log.append(f"Project path: {user_input} does not exist")
        migrate.append('Not Migrated')

def update_workbook_link(each_link,cloud_server,source_server,tree,file_path,file,item):
    expression = each_link.get('expression')
    if expression.endswith('/views'):
        expression = expression[:-len('/views')]
    all_workbooks = get_all_items(source_server, 'workbook')
    source_workbook_name=next((workbook.name for workbook in all_workbooks if workbook.webpage_url.split('#',2)[1]==expression.split('#',2)[1]),None)
    if source_workbook_name:
        all_workbooks = get_all_items(cloud_server, 'workbook')
        user_input = input("Provide the correct project path for Workbook: ")
        # user_input='/100 Workbooks'
        project_ids = get_project_ids(user_input, cloud_server)
        if project_ids:
            for workbook in all_workbooks:
                if workbook.name==source_workbook_name and workbook.project_id==project_ids:
                    each_link.set('expression', workbook.webpage_url)
                    tree.write(file_path, encoding="utf-8", xml_declaration=True)
                    logger_info("Successfully Updated The URL of Workbook")
        else:
            logger_error(f"Project path: {user_input} does not exist")
            workbook_names.append(source_workbook_name)
            log.append(f"Project path: {user_input} does not exist")
            migrate.append('Not Migrated')
    else:
        logger_error(f"Workbook '{source_workbook_name}' not found in tableau server")
        workbook_names.append(expression)
        log.append(f"Workbook '{source_workbook_name}' not found.")
        migrate.append('Not Migrated')

def update_datasource_link(each_link,cloud_server,cloud_site_name,file_path):
    pass
def update_flow_link(each_link,cloud_server,cloud_site_name,file_path):
    pass
def update_project_link(each_link,cloud_server,cloud_site_name,file_path):
    pass
def publish_workbook(cloud_server,project_lists):
    """
    Publishes workbooks from a local folder to Tableau Cloud projects.

    Args:
        cloud_server (Server): A Tableau Server Client object for interacting with the cloud server.
        project_lists (list): A list of project details, where each element
            is a tuple containing (project_name, project_path).

    Raises:
        OSError: If the workbook folder does not exist or there's an issue accessing files.
    """
    folder = os.path.join(os.getcwd(), 'workbook')
    for project_list in project_lists:
        project_path = project_list[1] if notna(project_list[1]) else project_list[0]
        project_ids=get_project_ids(project_path,cloud_server)
        if project_ids:
            all_workbooks=get_all_items(cloud_server,'workbook')
            project_workbooks = [workbook for workbook in all_workbooks if workbook.project_id == project_ids]

            for file in os.listdir(folder):
                file_path = os.path.join(folder, file)
                if os.path.isfile(file_path):
                    file_name=urllib.parse.unquote(file.split('_',1)[1].split('.twbx')[0])
                    matching_workbook = next((wb for wb in project_workbooks if wb.name == file_name), None)
                    if matching_workbook:
                        try:
                            print(f":: Publishing Workbook: {file_name}")
                            workbook_file_path=os.path.join(folder,file)
                            new_workbook = TSC.WorkbookItem(name=file_name,project_id=project_ids)
                            cloud_server.workbooks.publish(new_workbook,workbook_file_path,'Overwrite',skip_connection_check=True)
                            logger_info(f"Successfully published workbook :{file_name}")
                        except TSC.ServerResponseError as error:
                            workbook_names.append(f"Workbook :{urllib.parse.unquote(file.split('_', 1)[1].split('.twbx')[0])}")
                            log.append(f"Failed to publish workbook: {file_name} due to error: {error}")
                            migrate.append('Not Migrated')

                            logger_error(f"Failed to publish workbook: {file_name} due to error: {error}")
                        except Exception as error:
                            workbook_names.append(f"Workbook :{urllib.parse.unquote(file.split('_', 1)[1].split('.twbx')[0])}")
                            log.append(f"Failed to publish workbook: {file_name} due to error: {error}")
                            migrate.append('Not Migrated')

                            logger_error(f"Failed to publish workbook: {file_name} due to error: {error}")
                    else:
                        workbook_names.append(f"Workbook :{urllib.parse.unquote(file.split('_', 1)[1].split('.twbx')[0])}")
                        log.append(f"Workbook: {file_name} does not exist in the specified project.")
                        migrate.append('Not Migrated')

                        logger_error(f"Workbook: {file_name} does not exist in the specified project.")
        else:
            logger_error(f"Project path: {project_path} does not exist")

            workbook_names.append(f"Project path: {project_path} does not exist")
            log.append(f"No project Found")
            migrate.append('Not Migrated')


def main():
    """
    Main executor function
    :return:
    """
    logger_info("Starting the migration of Action URL's")
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None,help="Path to the .xlsx file containing project data.")
    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config_file = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a config file path")

    if excel_project:
        try:
            path = os.path.join(excel_project, 'project_path.xlsx')
            project_file = read_excel(path)
        except FileNotFoundError as e:
            logger_error(f"The specified project mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a Project Mapping file path")


    folder = os.path.join(os.getcwd(), 'workbook')
    if os.path.exists(folder):
        shutil.rmtree(folder)

    credentials=config_file["credentials"]
    source_server=Server(credentials["server"]["@path"], use_server_version=True)
    access_source = PersonalAccessTokenAuth(
        token_name=credentials["server"]["@pat_name"], personal_access_token=credentials["server"]["@pat"], site_id=credentials["server"]["@site"]
    )

    access_dest = PersonalAccessTokenAuth(
        token_name=credentials["cloud"]["@pat_name"], personal_access_token=credentials["cloud"]["@pat"], site_id=credentials["cloud"]["@site"]
    )
    dest_server = Server(credentials["cloud"]["@path"], use_server_version=True)

    with source_server.auth.sign_in(access_source):
        with dest_server.auth.sign_in(access_dest):
            get_action_url_workbooks(dest_server,project_file[project_file['Select'].str.lower() == 'yes'].values.tolist())
            open_matching_workbooks(source_server,dest_server,config_file["credentials"]["server"]["@site"],config_file["credentials"]["cloud"]["@site"])
            folder = os.path.join(os.getcwd(), 'workbook')
            for file in os.listdir(folder):
                file_path = os.path.join(folder, file)
                if os.path.isdir(file_path):
                    create_twbx(os.path.join(os.getcwd(), 'workbook', file),
                                f"{os.path.join(os.getcwd(), 'workbook', file)}.twbx")
            publish_workbook(dest_server,project_file[project_file['Select'].str.lower() == 'yes'].values.tolist())

    log_data = DataFrame({
        'Permission Name': workbook_names,
        'Log': log,
        'Status': migrate
    })

    file_name='migration_logs.xlsx'
    sheet_name = 'Action URL'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = openpyxl.load_workbook(file_path)
    except FileNotFoundError:
        workbook = openpyxl.Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)

    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)
    sheet.append(log_data.columns.tolist())
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
    workbook.save(file_path)
    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f"::::Execution time for migrating Action URL Migration is: {int(minutes)} min {int(seconds)} sec::::")
    logger_info(f"::::Migration log file generated : {file_path}::::")
    print(Fore.YELLOW + '\n\t\t\t---------------------- END OF ACTION URL MIGRATION ----------------------' + Style.RESET_ALL)

if __name__ == "__main__":
    main()