from tabulate import tabulate
from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from openpyxl.styles import Font
from pandas import DataFrame, notna, read_excel
from connection import login_to_tableau,get_all_items,get_project_ids

import os, argparse, requests, time, openpyxl, tableauserverclient as TSC

content_name = []
log = []
status = []

def get_content_owner(server, project_file):
    content_owner = []
    for excel_project in project_file:
        path = excel_project[1] if notna(excel_project[1]) else excel_project[0]
        project_ids = get_project_ids(excel_project[0], server)
        if project_ids:
            all_items = {
                'workbook': get_all_items(server, 'workbook'),
                'datasource': get_all_items(server, 'datasource'),
                'user': get_all_items(server, 'user')
            }
            user_emails = {}
            for user in all_items['user']:
                if user.email is None or user.email.strip() == '':
                    user_emails[user.id] = user.name
                else:
                    user_emails[user.id] = user.email
            for item_type in ('workbook', 'datasource'):
                for item in all_items[item_type]:
                    if item.project_id in project_ids:
                        content_owner.append([item.name, user_emails.get(item.owner_id), item_type, path])
        else:
            logger_error(f"Projects path:'{excel_project[0]}'not found in server")
            content_name.append('Project Path Does not Exist')
            log.append(f"Projects path:'{excel_project[0]}' not found in server")
            status.append('Not Migrated')

    return content_owner


def set_content_owner(cloud_server, user_list, content_list):
    new_content_list = []
    all_workbooks = get_all_items(cloud_server, 'workbook')
    all_datasource = get_all_items(cloud_server, 'datasource')
    all_users = get_all_items(cloud_server, 'user')

    for content in content_list:
        project_ids = get_project_ids(content[3], cloud_server)
        if project_ids:
            found = False
            all_items = {'workbook': all_workbooks, 'datasource': all_datasource}
            for item_type, all_items_of_type in all_items.items():
                if content[2] == item_type:
                    for item in all_items_of_type:
                        if item.name == content[0] and item.project_id in project_ids:
                            found = True
                            content.append(item.id)
                            new_content_list.append(content)
                            break
                    if not found:
                        logger_error(f"Content name:'{content[0]}' not found for {content[2]} in path:{content[3]}")
                        content_name.append(content[2])
                        log.append(f"Content name:'{content[0]}' not found for {content[2]} in path:{content[3]}")
                        status.append('Not migrated')
                    break
        else:
            logger_error(f"Projects path:'{content[3]}' not found for {content[2]} {content[0]}")
            content_name.append(content[2])
            log.append(f"Projects path:'{content[3]}' not found for {content[2]} {content[0]}")
            status.append('Not migrated')

    # Appending the user id in new content list:
    for content in new_content_list:
        if content[1] is not None:
            for excel_user in user_list:
                if excel_user[0] == content[1]:
                    content[1] = excel_user[2]
                elif content[1]==excel_user[1]:
                    content[1] = excel_user[2]
                    break
            user_id = next((user.id for user in all_users if user.email == content[1]), None)
            if user_id:
                content[1] = user_id
            else:
                new_content_list.remove(content)
                logger_error(f"User:{content[1]} not found for {content[2]} {content[0]}")
                content_name.append(content[2])
                log.append(f"User:{content[1]} not found for {content[2]} {content[0]}")
                status.append('Not migrated')
        else:
            logger_error(f"Email is not assign for {content[2]} {content[0]}")
            content_name.append(content[2])
            log.append(f"Email is not assign for {content[2]} {content[0]}")
            status.append('Not migrated')

    if len(new_content_list) > 0:
        for content in new_content_list:
            xml_request(cloud_server, content)
    else:
        logger_info("No content owner to update in the list")



def xml_request(cloud_server, content):
    xml_body = f"""
    <tsRequest>
    <{content[2]}>
            <owner id='{content[1]}'/>
    </{content[2]}>
    </tsRequest>
    """
    try:
        url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/{content[2]}s/{content[4]}"
        headers = {"Content-Type": "application/xml", "X-Tableau-Auth": cloud_server.auth_token}
        response = requests.put(url, headers=headers, data=xml_body)
        if response.status_code == 200:
            logger_info(f"Successfully updated owner for {content[2]}:{content[0]}")
            content_name.append(content[2])
            log.append(f"Successfully updated owner for {content[2]}:{content[0]}")
            status.append('Migrated')

        elif response.status_code == 403:
            logger_error(f"A non-administrator user tried to change the {content[2]} owner.")
            content_name.append(content[2])
            log.append(f"A non-administrator user tried to change the {content[2]} owner.")
            status.append('Not Migrated')
        elif response.status_code == 404:
            logger_error(f"Content not found for {content[2]}:{content[0]}")
            content_name.append(content[2])
            log.append(f"Content not found for {content[2]}:{content[0]}")
            status.append('Not Migrated')
        else:
            logger_error(f"Failed to update owner for {content[2]} {content[0]}. Status code: {response.text}")
            content_name.append(content[2])
            log.append(f"Failed to update owner for {content[2]} {content[0]}. Status code: {response.text}")
            status.append('Not Migrated')
    except TSC.ServerResponseError as error:
        logger_error(f"Tableau Error occurred: {error}")
        content_name.append(content[2])
        log.append(f"Failed to update owner for {content[2]} {content[0]}. Tableau Error occurred: {error}")
        status.append('Not Migrated')
    except Exception as error:
        logger_error(f"An error occurred: {error}")
        content_name.append(content[2])
        log.append(f"Failed to update owner for {content[2]} {content[0]}. An error occurred: {error}")
        status.append('Not Migrated')

def main():
    """
    Main executor function to migrate favorites
    """
    global user_file
    logger_info("::::Starting the Migration of content owners::::")
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None, help="Path to the .xlsx file containing project data.")
    parser.add_argument("--user", type=str, default=None, help="Path to the .xlsx file containing user data.")

    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project
    excel_user = args.user

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config_file = ReaderFactory(path).reader().to_json()
        except FileNotFoundError:
            logger_error(f"The specified config file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a config file path")

    if excel_project:
        try:
            path = os.path.join(excel_project, 'project_path.xlsx')
            project_file = read_excel(path)
        except FileNotFoundError:
            logger_error(f"The specified project mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a Project Mapping file path")

    if excel_user:
        try:
            path_u = os.path.join(excel_user, 'user_mapping.xlsx')
            user_file = read_excel(path_u, sheet_name='Users')
        except FileNotFoundError:
            logger_error(f"The specified user mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a User Mapping file path")

    # Get favorites from the server
    if len(project_file[project_file['Select'].str.lower() == 'yes'].values.tolist()) != 0:
       tableau_server=login_to_tableau(config_file['credentials']['server'])
       with tableau_server[0].auth.sign_in(tableau_server[1]):
           dist_list=get_content_owner(tableau_server[0], project_file[project_file['Select'].str.lower() == 'yes'].values.tolist())
    else:
        logger_error(f"No Project is Selected")
        exit(1)

    print(Fore.YELLOW + "\n\nContent :::\n" + Style.RESET_ALL)

    details_data = [[detail[0], detail[1], detail[2]] for detail in dist_list]
    details_headers = ["Content Name", "Content Owner", "Content Type"]
    print(Fore.CYAN + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    tableau_cloud=login_to_tableau(config_file['credentials']['cloud'])
    with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
        set_content_owner(tableau_cloud[0], user_file.values.tolist(), dist_list)

    log_data = DataFrame({
        'Entity Name': content_name,
        'Log': log,
        'Status': status
    })

    file_name = 'migration_logs.xlsx'
    sheet_name = 'Content Owner'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = openpyxl.load_workbook(file_path)
    except FileNotFoundError:
        workbook = openpyxl.Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)
    #
    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)
    sheet.append(log_data.columns.tolist())
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
    workbook.save(file_path)

    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f"::::Execution time for migrating Content Owner is: {int(minutes)} min {int(seconds)} sec::::")
    logger_info(f"::::Migration log file generated : {file_path}::::")

    print(
        Fore.YELLOW + '\n\t\t\t---------------------- END OF CONTENT OWNER MIGRATION ----------------------' + Style.RESET_ALL)


if __name__ == "__main__":
    main()
