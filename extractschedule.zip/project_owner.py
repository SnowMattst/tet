from tabulate import tabulate
from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from openpyxl import load_workbook,Workbook,styles
from pandas import notna,read_excel,DataFrame
from connection import login_to_tableau,get_project_ids,get_all_items
from tableauserverclient import ServerResponseError

import argparse,os,requests,time

Project_names = []
log = []
migrate = []

def get_project_owners(server,project_file):

    all_projects=get_all_items(server,'project')
    all_users=get_all_items(server,'user')
    project_owner = []
    for excel_project in project_file:
        path = excel_project[1] if notna(excel_project[1]) else excel_project[0]
        project_ids=get_project_ids(excel_project[0],server)
        if project_ids:
            for project in all_projects:
                if project.id==project_ids:
                    user_info=next((user.email or user.name for user in all_users if user.id==project.owner_id),None)
                    project_owner.append([project.name,user_info,path])
        else:
            logger_error(f"Could not find project path:{excel_project[0]}")
            Project_names.append(excel_project[0])
            log.append("Could not find project path")
            migrate.append("Not Migrated")

    return project_owner


def check_project_ownership(cloud_server,server_projects,user_file):

    new_project_list=[]
    all_users=get_all_items(cloud_server,'user')
    all_projects=get_all_items(cloud_server,'project')
    for server_project in server_projects:
        project_ids=get_project_ids(server_project[2],cloud_server)
        if project_ids:
            found = False
            for project in all_projects:
                if project.id==project_ids and project.name==server_project[0]:
                    found=True
                    server_project.append(project.id)
                    new_project_list.append(server_project)

            if not found:
                logger_error(f"Project {server_project[0]} does not exist on {cloud_server.server_address}")
                Project_names.append(server_project[0])
                log.append(f"Project {server_project[0]} does not exist on {cloud_server.server_address}")
                migrate.append("Not Migrated")
        else:
            logger_error(f"Could not find project path:{server_project[2]}")
            Project_names.append(server_project[0])
            log.append(f"Could not find project path:{server_project[2]}")
            migrate.append("Not Migrated")

    for project_list in new_project_list:
        if project_list[1] is not None:
            for excel_user in user_file:
                if excel_user[0] == project_list[1]:
                    project_list[1] = excel_user[2]
                elif project_list[1]==excel_user[1]:
                    project_list[1] = excel_user[2]
                    break
            user_id = next((user.id for user in all_users if user.email == project_list[1]), None)
            if user_id:
                project_list[1] = user_id
            else:
                new_project_list.remove(project_list)
                logger_error(f"User:{project_list[1]} not found for {project_list[2]} {project_list[0]}")
        else:
            logger_error(f"User is not assign for {project_list[2]} {project_list[0]}")

    if len(new_project_list) > 0:
        for content in new_project_list:
            xml_request(cloud_server, content)
    else:
        logger_info("No content owner to update in the list")
def xml_request(cloud_server, project_server):

    xml_body = f"""
    <tsRequest>
    <project>
            <owner id='{project_server[1]}'/>
    </project>
    </tsRequest>
    """
    try:
        url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/projects/{project_server[3]}"
        headers = {"Content-Type": "application/xml", "X-Tableau-Auth": cloud_server.auth_token}
        response = requests.put(url, headers=headers, data=xml_body)
        if response.status_code == 200:
            logger_info(f"Successfully updated owner for Project:{project_server[0]}")
        elif response.status_code == 403:
            logger_error(f"A non-administrator user:{next((user.name for user in get_all_items(cloud_server,'user') if user.id == project_server[1]), None)} can't be Project owner.")
        elif response.status_code == 404:
            logger_error(f"Content not found for Project:{project_server[0]}")
        else:
            logger_error(f"Failed to update owner for Project,Status code: {response.text}")
    except ServerResponseError as error:
        logger_error(f"Tableau Error occurred: {error}")
    except Exception as error:
        logger_error(f"An error occurred: {error}")



def main():
    """
    Main executor function
    :return:
    """
    logger_info("::: Starting Project Owner Migration :::")
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None,help="Path to the .xlsx file containing project data.")
    parser.add_argument("--user", type=str, default=None, help="Path to the .xlsx file containing user data.")
    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project
    excel_user = args.user

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config_file = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in: {path}")
            exit(1)
    else:
        logger_error(f"Please specified Config file path")

    if excel_project:
        try:
            path = os.path.join(excel_project, 'project_path.xlsx')
            project_file = read_excel(path)
        except FileNotFoundError as e:
            logger_error(f"The specified project mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error(f"Please specified project mapping file path")

    if excel_user:
        try:
            path_u = os.path.join(excel_user, 'user_mapping.xlsx')
            user_file =read_excel(path_u, sheet_name='Users')
        except FileNotFoundError as e:
            logger_error(f"The specified user mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error(f"Please specified user mapping file path")

    # Login to Tableau Server:
    tableau_server = login_to_tableau(config_file["credentials"]['server'])
    with tableau_server[0].auth.sign_in(tableau_server[1]):
        dist=get_project_owners(tableau_server[0],project_file[project_file['Select'].str.lower() == 'yes'].values.tolist())

    print("\n\nProjects :::\n")
    details_data = [
        [detail[0], detail[1], detail[2]] for detail in dist]
    details_headers = ["Project Name ", "Owner","Project Path"]
    print(Fore.CYAN + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    tableau_cloud=login_to_tableau(config_file['credentials']['cloud'])
    with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
        check_project_ownership(tableau_cloud[0],dist,user_file.values.tolist())

    log_data = DataFrame({
        'Project Name': Project_names,
        'Log': log,
        'Status': migrate
    })

    file_name='migration_logs.xlsx'
    sheet_name = 'Project Owner'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = load_workbook(file_path)
    except FileNotFoundError:
        workbook = Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)

    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)
    sheet.append(log_data.columns.tolist())
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
    for cell in sheet[1]:
        cell.font = styles.Font(bold=True)
    workbook.save(file_path)
    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f":::: Execution time for migrating Project Owner is: {int(minutes)} min {int(seconds)} sec ::::")
    logger_info(f":::: Migration log file generated : {file_path} ::::")
    print(Fore.YELLOW + '\n\t\t\t---------------------- END OF PROJECT OWNER MIGRATION ----------------------' + Style.RESET_ALL)

if __name__ == "__main__":
    main()