import argparse
import os

import pandas as pd
import tableauserverclient as TSC
from tableauserverclient import *

from config_reader.reader_factory import ReaderFactory
from logger.logger import *


def create_excel_csv(filename,server):
    if isinstance(server, dict):
        server = [server]

    for sf in server:
        source = sf.get("@path")
        pat_name = sf.get("@pat_name")
        pat_secret = sf.get("@pat")
        site = sf.get("@site")

        if not source or not pat_name or not pat_secret :
            logger_info("Missing necessary server configuration details.")
            continue

        # Create the authentication object
        credentials = PersonalAccessTokenAuth(
            token_name=pat_name, personal_access_token=pat_secret, site_id=site
        )

        # Create a server object
        tableau_server = Server(source, use_server_version=True)

        # Authenticate the server
        with tableau_server.auth.sign_in(credentials):
            group_names = [group.name for group in
                           TSC.Pager(tableau_server.groups)]

            # Create a dataframe from the user emails
            df = pd.DataFrame({
                'Source Group_Name': group_names,
                'Destination Group_Name': ['' for _ in range(len(group_names))],
                'Select': ['no' for _ in range(len(group_names))]
            })
            # # Write the dataframe to an Excel file
            df.to_excel(filename, index=False)
            # Write the dataframe to a CSV file
            #df.to_csv(filename, index=False)
        return filename


def main():
    """
    Main executor function
    :return:
    """
    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--r", type=str, default=None, help="Path to the XML file.")
    args = parser.parse_args()
    userpath = args.r

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        try:
            path = os.path.join(os.path.expanduser("~"), 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    # File name for the Excel file
    filename = 'group_mapping.xlsx'
    try:
        # Create an Excel file with dummy data
        file_path = create_excel_csv(filename, config['credentials']["server"])
        logger_info(f"File created at: {file_path}")

    except PermissionError:
        logger_error("Permission error occurred during file creation.")

    except FileNotFoundError:
        logger_error("File not found error occurred during file creation.")

    except Exception as e:
        logger_error(f"An unexpected error occurred during file creation: {e}")

if __name__ == "__main__":
    main()

