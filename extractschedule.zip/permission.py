from config_reader.reader_factory import ReaderFactory
from pandas import read_excel,notna,DataFrame
from tabulate import tabulate
from logger.logger import *
from openpyxl.styles import Font
from connection import login_to_tableau,get_project_ids,get_all_items,get_full_project_path

import time, os, argparse,openpyxl,json,xmltodict,requests,xml.etree.ElementTree as ET,tableauserverclient as TSC

permission_names = []
log = []
migrate = []

def delete_permission(cloud_server,permissions,successful_permissions,unsuccessful_permissions):

    headers = {
        "Content-Type": "application/xml",
        "Accept": "application/json",
        "X-Tableau-Auth": cloud_server.auth_token
    }

    for cap_name, cap_mode in permissions['capabilities'].items():
        new_cap_mode = 'Deny' if cap_mode == 'Allow' else 'Allow'
        url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/{permissions['entity_type']}s/{permissions['entity_id']}/permissions/{permissions['tag']}s/{permissions['grantee_id']}/{cap_name}/{new_cap_mode}"
        response = requests.delete(url, headers=headers)
        if response.status_code == 204:
            logger_info(
                f"Successfully deleted permissions for {permissions['tag']}: {permissions['grantee_name']} in {permissions['entity_type']}")
            xml_request(cloud_server, permissions, successful_permissions, unsuccessful_permissions,'no')

def get_project_default_permissions(server,project_list,template,point):

    all_project=list(TSC.Pager(server.projects))
    groups = get_all_items(server, 'group')
    users = get_all_items(server, 'user')

    all_permissions=[]

    keys = {'AddComment', 'ViewComments', 'RunExplainData', 'Read', 'ExportData', 'Filter',
            'ExportImage'}
    for data in project_list:
        project_id = get_project_ids(data[0], server)
        for project in all_project:
            if project.id == project_id:
                server.projects.populate_workbook_default_permissions(project)
                server.projects.populate_datasource_default_permissions(project)
                server.projects.populate_flow_default_permissions(project)
                permissions = {'default workbook': project.default_workbook_permissions,'default datasource': project.default_datasource_permissions,'default flow': project.default_flow_permissions}
                for default_type,permission in permissions.items():
                    for per in permission:
                        if template=='yes' and point=='server':
                            if default_type == 'default workbook':
                                dict_key = per.capabilities.keys()
                                if keys == dict_key:
                                    per.capabilities.pop('RunExplainData')
                        if per.grantee.tag_name == 'group':
                            entity_p = next((group.name for group in groups if group.id == per.grantee.id), None)
                        elif per.grantee.tag_name == 'user':
                            entity_p = next((user.email or user.name for user in users if user.id == per.grantee.id), None)
                        all_permissions.append({
                            'entity_name': project.name,'entity_id': project.id,
                            'tag': per.grantee.tag_name,'grantee_name': entity_p,
                            'grantee_id': per.grantee.id,'capabilities': per.capabilities,
                            'project_path':data[0],'entity_type': default_type,
                        })

    return all_permissions

def get_server_templates(data):
    workbook =data[data['Workbooks'].notnull()][['Capabilities', 'Workbooks','Template']].values.tolist()
    datasource =data[data['Datasource'].notnull()][['Capabilities', 'Datasource','Template']].values.tolist()
    flow=data[data['Flows'].notnull()][['Capabilities', 'Flows','Template']].values.tolist()
    return workbook, datasource, flow
def get_all_template_permission(server,project_list,template,point):
    """
    Retrieves all permissions for entities (projects, datasources, workbooks, flows, views)
    within the specified projects, considering user and group access levels.

    Args:
        server (tableau.server.Server): The Tableau Server connection object.
        project_list (list): A list of project paths (strings).
    Returns:
        list: A list of dictionaries containing entity permissions in the specified format.
    Raises:
        Exception: If an error occurs while fetching permissions or project IDs.
    """

    # Fetch all entities, groups, and users from the server
    all_project = get_all_items(server, 'project')
    all_datasource = get_all_items(server, 'datasource')
    all_flow = get_all_items(server, 'flow')
    all_workbook = get_all_items(server, 'workbook')
    all_view = get_all_items(server, 'view')
    groups = get_all_items(server, 'group')
    users = get_all_items(server, 'user')
    # Create dictionaries for quick access to user and group names
    group_names = {group.id: group.name for group in groups}
    user_names = {user.id: user.email or user.name for user in users}

    entity_types = {
        'project': (all_project, 'parent_id', server.projects),
        'datasource': (all_datasource, 'project_id', server.datasources),
        'workbook': (all_workbook, 'project_id', server.workbooks),
        'flow': (all_flow, 'project_id', server.flows),
        'view': (all_view, 'project_id', server.views),
    }

    all_permissions = []

    for project_path in project_list:
        try:
            project_id = get_project_ids(project_path[0], server)
        except Exception as e:
            print(f"Error getting project ID for {project_path[0]}: {e}")
            continue

        for entity_type, (entities, id_field, server_entity) in entity_types.items():
            for entity in entities:
                if getattr(entity, id_field) == project_id or entity.id == project_id:
                    server_entity.populate_permissions(entity)
                    content_permission = entity.content_permissions if entity_type == 'project' else None

                    workbook_name = None
                    if entity_type == 'view':
                        workbook_name = next(
                            (workbook.name for workbook in all_workbook if workbook.id == entity.workbook_id), None)

                    for permission in entity.permissions:
                        if point == 'server' and template == 'yes' and entity_type == 'workbook':
                            if set(permission.capabilities.keys()) == {'AddComment', 'ViewComments', 'RunExplainData','Read', 'ExportData', 'Filter', 'ExportImage'}:
                                permission.capabilities.pop('RunExplainData', None)
                        entity_p = group_names.get(permission.grantee.id) if permission.grantee.tag_name == 'group' else user_names.get(permission.grantee.id)
                        entity_permissions = [{
                            'entity_name': entity.name,
                            'entity_id': entity.id,
                            'project_path': project_path[0],
                            'entity_type': 'Main project' if entity.id == project_id and point == 'server' else entity_type,
                            'tag': permission.grantee.tag_name,
                            'grantee_name': entity_p,
                            'grantee_id': permission.grantee.id,
                            'capabilities': permission.capabilities,
                            'content_permission': content_permission,
                            'workbook_name': workbook_name
                        }]
                        all_permissions.extend(entity_permissions)
    return all_permissions
def migrate_default_permission(cloud_server, entity_list, project_data, user_file,group_file,template):

    all_project=list(TSC.Pager(cloud_server.projects))
    groups=list(TSC.Pager(cloud_server.groups))
    users=list(TSC.Pager(cloud_server.users))

    matched_entity=[]
    unmatched_entity=[]

    for excel_project in project_data:
        project_path = excel_project[1] if notna(excel_project[1]) else excel_project[0]
        project_ids = get_project_ids(project_path, cloud_server,)
        if project_ids is None:
            logger_error(f"Project path :{project_path} does not exist")
            unmatched_entity.append(excel_project)
            continue
        else:
            for entity in entity_list:
                if entity['project_path'] == project_path:
                    entity['entity_id'] = project_ids
                    matched_entity.append(entity)
    successful_permissions=[]
    unsuccessful_permissions=[]

    for entity in matched_entity[:]:
        if entity['tag'] == 'user':
            for excel_user in user_file:
                if entity['grantee_name'] == excel_user[0]:
                    entity['grantee_id'] = next((user.id for user in users if user.email == excel_user[2]), None)
                    entity['grantee_name'] = excel_user[2]
                    break
            if entity['grantee_id'] is None:
                matched_entity.remove(entity)
                unsuccessful_permissions.append(entity)
                logger_error(f"User {entity['grantee_name']} not found in Tableau Server")
                continue
        elif entity['tag'] == 'group':
            for excel_group in group_file:
                if entity['grantee_name'] == excel_group[0]:
                    entity['grantee_id'] = next((group.id for group in groups if group.name == excel_group[1]), None)
                    entity['grantee_name'] = excel_group[1]
                    break
            if entity['grantee_id'] is None:
                matched_entity.remove(entity)
                unsuccessful_permissions.append(entity)
                logger_error(f"Group {entity['grantee_name']} not found in Tableau Server")
                continue
    if template=='yes':
        cloud_d_permission=get_project_default_permissions(cloud_server,project_data,template,'cloud')
        headers = {
            "Content-Type": "application/xml",
            "Accept": "application/json",
            "X-Tableau-Auth": cloud_server.auth_token
        }
        for cloud in cloud_d_permission:
            for server in matched_entity:
                entity_s = server['entity_type'].replace("default ", "")
                entity_c = cloud['entity_type'].replace("default ", "")
                if server['entity_id']==cloud['entity_id'] and entity_c==entity_s and server['grantee_id']==cloud['grantee_id']:
                    if server['capabilities']!=cloud['capabilities']:
                        logger_error(f"Template Conflict for {server['entity_type']}:{server['entity_name']}")
                        while True:
                            user_input = input("Enter 'y' to delete or 'n' to skip: ").strip().lower()
                            if user_input == 'y':
                                logger_info(f"Deleting the {server['entity_type']} permissions: {server['entity_name']} for {server['tag']}:{server['grantee_name']}")
                                for cap_name,cap_mode in cloud['capabilities'].items():
                                    url=f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/projects/{server['entity_id']}/default-permissions/{entity_s}s/{cloud['tag']}s/{cloud['grantee_id']}/{cap_name}/{cap_mode}"
                                    response = requests.delete(url, headers=headers)
                                    if response.status_code == 204:
                                        logger_info(f"Successfully deleted permissions for {cloud['tag']}: {cloud['grantee_name']} in {cloud['entity_type']}")
                                    else:
                                        logger_error(f"Failed to delete permissions for {cloud['tag']}: {cloud['grantee_name']} in {cloud['entity_type']} with status code {response.status_code}")
                                break
                            elif user_input == 'n':
                                logger_info(f"Skipping the {server['entity_type']} permissions: {server['entity_name']} for {server['tag']}:{server['grantee_name']}")
                                matched_entity.remove(server)
                                permission_names.append(f"Type: {server['entity_type']}, Name: {server['entity_name']}")
                                log.append(
                                    f"Permission Skipped for {server['entity_type']}:{server['grantee_name']}")
                                migrate.append('Permission Not migrated')
                                unsuccessful_permissions.append(server)
                                break
                            else:
                                print("Invalid input. Please enter 'y' or 'n'.")

    print("\n\nMatching entities :::")
    details_data = [[dist['entity_name'], dist['tag'], dist['entity_type'], dist['project_path']] for dist in matched_entity]
    details_headers = ["Entity Name ", "Tag", "Entity Type", "Project Path", "Permission Owner"]
    print(Fore.YELLOW + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    print("\n\nUnMatching entities :::")
    details_data = [[dist['entity_name'], dist['tag'], dist['entity_type'], dist['project_path']] for dist in unmatched_entity]
    details_headers = ["Entity Name ", "Tag", "Entity Type", "Project Path", "Permission Owner"]
    print(Fore.YELLOW + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)
    for entity_data in matched_entity:
        request_xml_default(cloud_server, entity_data, successful_permissions, unsuccessful_permissions)

def compare_permission(cloud_server,server_permission,cloud_permission,unsuccessful_permissions):
    for cloud in cloud_permission:
        for server in server_permission:
            if server['entity_id'] == cloud['entity_id'] and server['grantee_name'] == cloud['grantee_name']:
                if server['capabilities']!=cloud['capabilities']:
                    logger_error(f"Template Conflict for {server['entity_type']}:{server['entity_name']}")
                    while True:
                        user_input = input("Enter 'y' to delete or 'n' to skip: ").strip().lower()
                        if user_input == 'y':
                            logger_info(f"Deleting the {server['entity_type']} permissions: {server['entity_name']}")
                            headers = {
                                "Content-Type": "application/xml","Accept": "application/json",
                                "X-Tableau-Auth": cloud_server.auth_token
                            }
                            for cap_name, cap_mode in cloud['capabilities'].items():
                                url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/{cloud['entity_type']}s/{cloud['entity_id']}/permissions/{cloud['tag']}s/{cloud['grantee_id']}/{cap_name}/{cap_mode}"
                                response = requests.delete(url, headers=headers)
                                if response.status_code == 204:
                                    logger_info(f"Successfully deleted permissions for {cloud['tag']}: {cloud['grantee_name']} in {cloud['entity_type']}")
                                else:
                                    logger_error(
                                        f"Failed to delete permissions for {cloud['tag']}: {cloud['grantee_name']} in {cloud['entity_type']} {response.text}")
                                    unsuccessful_permissions.append(server)
                            break
                        elif user_input == 'n':
                            logger_info(f"Skipping the {server['entity_type']} permissions: {server['entity_name']}")
                            server_permission.remove(server)
                            permission_names.append(f"Type: {server['entity_type']}, Name: {server['entity_name']}")
                            log.append(
                                f"Permission Skipped for {server['entity_type']}:{server['grantee_name']}")
                            migrate.append('Permission Not migrated')
                            unsuccessful_permissions.append(server)
                            break
                        else:
                            print("Invalid input. Please enter 'y' or 'n'.")
                break
    return server_permission
def migrate_all_permission(cloud_server, entity_list, project_data, user_file,group_file,template):

    all_project=get_all_items(cloud_server,'project')
    all_datasource=list(TSC.Pager(cloud_server.datasources))
    all_flow=list(TSC.Pager(cloud_server.flows))
    all_workbook=list(TSC.Pager(cloud_server.workbooks))
    all_view=list(TSC.Pager(cloud_server.views))
    groups=list(TSC.Pager(cloud_server.groups))
    users=list(TSC.Pager(cloud_server.users))

    for excel_project in project_data:
        project_ids = None

        if notna(excel_project[1]):
            project_ids = get_project_ids(excel_project[1], cloud_server)
        else:
            project_ids = get_project_ids(excel_project[0], cloud_server)

        if project_ids is not None:
            for entity in entity_list:
                if entity['project_path'] == excel_project[1] or entity['project_path'] == excel_project[0]:
                    entity['project_id'] = project_ids
        else:
            logger_error(
                f"Project path {excel_project[1] if notna(excel_project[1]) else excel_project[0]} does not exist")

    matched_entity=[]
    unmatched_entity=[]

    successful_permissions=[]
    unsuccessful_permissions=[]

    entity_types = {
        'datasource': (all_datasource, 'project_id'),
        'workbook': (all_workbook, 'project_id'),
        'flow': (all_flow, 'project_id')
    }
    for entity in entity_list:
        entity_found = False
        for entity_type, (entities, id_field) in entity_types.items():
            if entity['entity_type'] == entity_type:
                for ent in entities:
                    if (entity['entity_name'] == ent.name and entity['project_id'] == getattr(ent, id_field)) or ( entity['project_id'] == ent.id):
                        entity_found = True
                        entity['entity_id'] = ent.id
                        matched_entity.append(entity)
                        break
                if entity_found:
                    break
        if entity['entity_type'] == 'project':
            for project in all_project:
                if entity['entity_name']==project.name and entity['project_id']==project.parent_id:
                    entity['entity_id'] = project.id
                    entity_found = True
                    if entity not in matched_entity:
                        matched_entity.append(entity)
                    break
        if entity['entity_type'] == 'Main project':
            for project in all_project:
                if entity['entity_name']==project.name and entity['project_id']==project.id:
                    entity['entity_id'] = project.id
                    entity['entity_type']='project'
                    entity_found = True
                    if entity not in matched_entity:
                        matched_entity.append(entity)
                    break
        if entity['entity_type'] == 'view':
            for workbook in all_workbook:
                if entity['workbook_name'] == workbook.name and entity['project_id'] == workbook.project_id:
                    for view in all_view:
                        if view.workbook_id == workbook.id and view.name == entity['entity_name']:
                            entity['entity_id'] = view.id

                            entity_found = True
                            if entity not in matched_entity:
                                matched_entity.append(entity)
                            break
                    break
        if not entity_found:
            logger_error(f"{entity['entity_type']}: {entity['entity_name']} not found in project path :{entity['project_path']}")

            permission_names.append(f"Type: {entity['entity_type']}, Name: {entity['entity_name']}")
            log.append(f"{entity['entity_type']} Not present inside the project path :{entity['project_path']}")
            migrate.append('Permission not migrated')
            unmatched_entity.append(entity)

    for entity in matched_entity[:]:
            if entity['tag']=='user':
                for excel_user in user_file:
                    if entity['grantee_name'] == excel_user[0]:
                        entity['grantee_id'] = next((user.id for user in users if user.email == excel_user[2]), None)
                        entity['grantee_name'] = excel_user[2]
                        break
                    if entity['grantee_name'] == excel_user[1]:
                        entity['grantee_id'] = next((user.id for user in users if user.email == excel_user[2]), None)
                        entity['grantee_name'] = excel_user[2]
                        break

                if entity['grantee_id'] is None:
                    matched_entity.remove(entity)
                    unsuccessful_permissions.append(entity)
                    permission_names.append(f"Type: {entity['entity_type']}, Name: {entity['entity_name']}")
                    log.append(f"{entity['grantee_name']} Not present On Cloud")
                    migrate.append('Permission not migrated')
                    logger_error(f"User {entity['grantee_name']} not found in Tableau Server")
                    continue
            if entity['tag']=='group':
                for excel_group in group_file:
                    if entity['grantee_name'] == excel_group[0]:
                        entity['grantee_id'] = next((group.id for group in groups if group.name == excel_group[1]),None)
                        entity['grantee_name'] = excel_group[1]
                        break
                    if entity['grantee_name'] == excel_group[1]:
                        entity['grantee_id'] = next((user.id for user in users if user.email == excel_group[2]), None)
                        entity['grantee_name'] = excel_group[2]
                        break

                if entity['grantee_id'] is None:
                    matched_entity.remove(entity)
                    permission_names.append(f"Type: {entity['entity_type']}, Name: {entity['entity_name']}")
                    log.append(f"{entity['grantee_name']} Not present On Cloud")
                    migrate.append('Permission not migrated')
                    unsuccessful_permissions.append(entity)
                    logger_error(f"Group {entity['grantee_name']} not found in Tableau Server")
                    continue
    if template=='yes':
        cloud_permission=get_all_template_permission(cloud_server,project_data,template,'cloud')
        main_p=compare_permission(cloud_server,matched_entity,cloud_permission,unsuccessful_permissions)
        matched_entity=main_p
    print("\n\nMatching entities :::")
    details_data = [[dist['entity_name'], dist['entity_type'], dist['project_path']] for dist in matched_entity]
    details_headers = ["Entity Name ","Entity Type", "Project Path","Permission Owner"]
    print(Fore.YELLOW + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    print("\n\nUnMatching entities :::")
    details_data = [[dist['entity_name'], dist['entity_type'], dist['project_path']] for dist in unmatched_entity]
    details_headers = ["Entity Name ","Entity Type", "Project Path","Permission Owner"]
    print(Fore.YELLOW + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    for entity_item in matched_entity:
        xml_request(cloud_server,entity_item,successful_permissions, unsuccessful_permissions,template)

    for entity in matched_entity:
        for my_project in all_project:
            if my_project.id==entity['grantee_id']:
                my_project.content_permissions = 'ManagedByOwner'
                cloud_server.projects.update(my_project)
    for entity_item in matched_entity:
        if entity_item['entity_type']=='project':
            for my_project in all_project:
                if my_project.id == entity_item['entity_id']:
                    my_project.content_permissions=entity_item['content_permission']
                    cloud_server.projects.update(my_project)
    for entity_item in matched_entity:
        headers = {"Content-Type": "application/xml", "Accept": "application/json",
                   "X-Tableau-Auth": cloud_server.auth_token}
        # if entity_item['entity_type'] == 'project':
        #     delete_url_I = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/{entity_item['entity_type']}s/{entity_item['entity_id']}/permissions/{entity_item['tag']}s/{entity_item['grantee_id']}/InheritedProjectLeader/Allow"
        #     requests.delete(delete_url_I, headers=headers, timeout=45)
    print("\n\nSuccessful entities :::")
    details_data = [[dist['entity_name'], dist['entity_type'], dist['project_path']] for dist in successful_permissions]
    details_headers = ["Entity Name ","Entity Type", "Project Path"]
    print(Fore.YELLOW + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    print("\n\nUnSuccessful entities :::")
    details_data = [[dist['entity_name'], dist['entity_type'], dist['project_path']] for dist in unsuccessful_permissions]
    details_headers = ["Entity Name ","Entity Type", "Project Path"]
    print(Fore.YELLOW + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

def request_xml_default(cloud_server,entity_item,successful_permissions, unsuccessful_permissions):

    headers = {"Content-Type": "application/xml", "Accept": "application/json",
               "X-Tableau-Auth": cloud_server.auth_token}
    entity = entity_item['entity_type'].replace("default ", "")
    url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/projects/{entity_item['entity_id']}/default-permissions/{entity}s"
    request = ET.Element("tsRequest")
    permission = ET.SubElement(request, "permissions")
    grantee = ET.SubElement(permission, "granteeCapabilities")
    ET.SubElement(grantee, entity_item['tag'], id=entity_item['grantee_id'])
    capabilities = ET.SubElement(grantee, "capabilities")
    for name, mode in entity_item['capabilities'].items():
        ET.SubElement(capabilities, "capability", name=name, mode=mode)
    try:
        response = requests.put(url, headers=headers, data=ET.tostring(request, encoding="unicode"), timeout=45)
        if response.status_code == 200:
            logger_info(f"Successfully Added default permission {entity_item['tag']}: {entity_item['grantee_name']} for {entity_item['entity_type']} Name :{entity_item['entity_name']}")
            successful_permissions.append(entity_item)
        else:
            logger_error(response.text)
            logger_error(f"Failed to migrated permission for {entity_item['entity_type']}:{entity_item['entity_name']} -- {entity_item['tag']}:{entity_item['grantee_name']}")
            unsuccessful_permissions.append(entity_item)
    except Exception as e:
        logger_error(f'Failed to migration permission :{e}')
    return successful_permissions, unsuccessful_permissions


def xml_request(cloud_server,entity_item,successful_permissions, unsuccessful_permissions,template):

    headers = {"Content-Type": "application/xml", "Accept": "application/json",
               "X-Tableau-Auth": cloud_server.auth_token}
    if entity_item['entity_type']=='project':
        # delete_url_I=f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/{entity_item['entity_type']}s/{entity_item['entity_id']}/permissions/{entity_item['tag']}s/{entity_item['grantee_id']}/InheritedProjectLeader/Allow"
        # requests.delete(delete_url_I, headers=headers, timeout=45)
        delete_url_P=f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/{entity_item['entity_type']}s/{entity_item['entity_id']}/permissions/{entity_item['tag']}s/{entity_item['grantee_id']}/ProjectLeader/Allow"
        requests.delete(delete_url_P, headers=headers, timeout=45)

    url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/{entity_item['entity_type']}s/{entity_item['entity_id']}/permissions"
    request = ET.Element("tsRequest")
    permission = ET.SubElement(request, "permissions")
    ET.SubElement(permission, entity_item['entity_type'], id=entity_item['entity_id'])
    grantee = ET.SubElement(permission, "granteeCapabilities")
    ET.SubElement(grantee, entity_item['tag'], id=entity_item['grantee_id'])
    capabilities = ET.SubElement(grantee, "capabilities")
    for name, mode in entity_item['capabilities'].items():
        ET.SubElement(capabilities, "capability", name=name, mode=mode)
    try:
        response = requests.put(url, headers=headers, data=ET.tostring(request, encoding="unicode"), timeout=45)
        if response.status_code == 200:
            logger_info(f"Successfully Added {entity_item['tag']}: {entity_item['grantee_name']} for {entity_item['entity_type']} Name :{entity_item['entity_name']}")
            successful_permissions.append(entity_item)

            permission_names.append(f"Type: {entity_item['entity_type']}, Name: {entity_item['entity_name']}")
            log.append(f"Successfully Added Permission for {entity_item['tag']}: {entity_item['grantee_name']}")
            migrate.append('Permission migrated')
        elif response.status_code == 404:
            logger_error(f"{entity_item['tag'].upper()} not found with the id: {entity_item['grantee_name']} for {entity_item['entity_name']}")
            unsuccessful_permissions.append(entity_item)

            permission_names.append(f"Type: {entity_item['entity_type']}, Name: {entity_item['entity_name']}")
            log.append(f"{entity_item['tag']}:{entity_item['grantee_name']} not found on cloud")
            migrate.append('Permission Not migrated')
        elif response.status_code == 409:
            logger_error(f"Resource Conflict: {entity_item['grantee_name']} for {entity_item['tag']} in {entity_item['entity_type']}: {entity_item['entity_name']} ")
            while True:
                user_input = input("Enter 'y' to delete or 'n' to skip: ").strip().lower()
                if user_input == 'y':
                    logger_info(f"Deleting the {entity_item['entity_type']} permissions: {entity_item['entity_name']}")
                    delete_permission(cloud_server, entity_item,successful_permissions,unsuccessful_permissions)
                    break
                elif user_input == 'n':
                    logger_info(f"Skipping the {entity_item['entity_type']} permissions: {entity_item['entity_name']}")

                    permission_names.append(f"Type: {entity_item['entity_type']}, Name: {entity_item['entity_name']}")
                    log.append(f"Permission Skipped for {entity_item['entity_type']}:{entity_item['grantee_name']}")
                    migrate.append('Permission Not migrated')
                    unsuccessful_permissions.append(entity_item)
                    break
                else:
                    print("Invalid input. Please enter 'y' or 'n'.")

        else:
            logger_error(f"Failed to set permissions: {response.text}")
            unsuccessful_permissions.append(entity_item)
            permission_names.append(f"Type: {entity_item['entity_type']}, Name: {entity_item['entity_name']}")
            log.append(f"Error: {response.text}")
            migrate.append('Permission Not migrated')

    except TSC.ServerResponseError as server_err:
        logger_error(f"Failed to set permissions: {server_err}")
        unsuccessful_permissions.append(entity_item)

        permission_names.append(f"Type: {entity_item['entity_type']}, Name: {entity_item['entity_name']}")
        log.append(f"Error: {server_err}")
        migrate.append('Permission Not migrated')


    return successful_permissions, unsuccessful_permissions
def download(server_filters, project_data,template):
   tableau_server=login_to_tableau(server_filters)
   with tableau_server[0].auth.sign_in(tableau_server[1]):
        if template=='yes':
            logger_info(":::: Starting the migration of Permissions Templates wise ::::")
            p_list=get_all_template_permission(tableau_server[0],project_data,template,'server')
        else:
            logger_info(":::: Starting the migration of Permissions Capabilities wise ::::")
            p_list=get_all_template_permission(tableau_server[0],project_data,'no','server')
        d_list=get_project_default_permissions(tableau_server[0], project_data, template,'server')
        return p_list, d_list

def main():
    """
    Main executor function
    :return:
    """
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None,
                        help="Path to the .xlsx file containing project data.")
    parser.add_argument("--user", type=str, default=None,
                        help="Path to the .xlsx file containing user data.")
    parser.add_argument("--template", type=str, default=None,help="Path to the .xlsx file containing user data.")
    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project
    excel_user = args.user
    template = args.template

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            parse_dict = xmltodict.parse(open(path, 'r').read())
            json_string = json.dumps(parse_dict)
            config_file = json.loads(json_string)
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please specify a config file")

    if excel_project:
        try:
            path = os.path.join(excel_project, 'project_path.xlsx')
            project_file =read_excel(path)
        except FileNotFoundError as e:
            logger_error(f"The specified project mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error(f"Please specify project mapping file")

    if excel_user:
        try:
            path = os.path.join(excel_user, 'user_mapping.xlsx')
            user_file =read_excel(path, sheet_name='Users')
            group_file = read_excel(path, sheet_name='Groups')
        except FileNotFoundError as e:
            logger_error(f"The specified user mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error(f"Please specify user mapping file")

    # Download the project from the server
    if len(project_file[project_file['Select'].str.lower() == 'yes'].values.tolist()) != 0:
        dist_list = download(config_file["credentials"]['server'],project_file[project_file['Select'].str.lower() == 'yes'].values.tolist(),template)

    else:
        logger_error(f"::: No Project is Selected :::")
        exit(1)
    tableau_cloud=login_to_tableau(config_file["credentials"]['cloud'])
    with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
        logger_info("APPLYING DEFAULT PERMISSION ::::")
        entity_types = {
            'default workbook':["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Permission Owner"],
            'default datasource':["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Permission Owner"],
            'default flow': ["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Permission Owner"],
        }
        for entity_type, headers in entity_types.items():
            details_data = [[dist['entity_name'], dist['tag'], dist['entity_type'], dist['project_path'],dist['grantee_name']]for dist in dist_list[1] if dist['entity_type'] == entity_type]
            print(f"\n\n{entity_type.upper()} :::")
            print(Fore.CYAN + tabulate(details_data, headers=headers, tablefmt="grid") + Style.RESET_ALL)
        migrate_default_permission(tableau_cloud[0], dist_list[1],project_file[project_file['Select'].str.lower() == 'yes'].values.tolist(),user_file.values.tolist(),group_file.values.tolist(),template)

        logger_info("APPLYING PERMISSION FOR ENTITY'S ::::")
        entity_types = {
            'project': ["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Permission Owner"],
            'workbook': ["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Permission Owner"],
            'datasource': ["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Permission Owner"],
            'flow': ["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Permission Owner"],
            'view': ["Entity Name ", "Permission Type", "Entity Type", "Project Path", "Workbook Name"],
        }

        for entity_type, headers in entity_types.items():
            details_data = [[dist['entity_name'], dist['tag'], dist['entity_type'], dist['project_path'],
                             dist['grantee_name'] if 'grantee_name' in dist else dist['workbook_name']]
                            for dist in dist_list[0] if dist['entity_type'] == entity_type]
            print(f"\n\n{entity_type.upper()} :::")
            print(Fore.CYAN + tabulate(details_data, headers=headers, tablefmt="grid") + Style.RESET_ALL)

        migrate_all_permission(tableau_cloud[0], dist_list[0],project_file[project_file['Select'].str.lower() == 'yes'].values.tolist(),user_file.values.tolist(),group_file.values.tolist(),template)
    log_data =DataFrame({
        'Permission Name': permission_names,
        'Log': log,
        'Status': migrate
    })

    file_name = 'migration_logs.xlsx'
    sheet_name = 'Permission'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = openpyxl.load_workbook(file_path)
    except FileNotFoundError:
        workbook = openpyxl.Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)

    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)
    sheet.append(log_data.columns.tolist())
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    workbook.save(file_path)

    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f"::::Execution time for migrating Permission is: {int(minutes)} min {int(seconds)} sec::::")
    logger_info(f"::::Migration log file generated : {file_path}::::")
    print(Fore.YELLOW + '\n\t\t\t---------------------- END OF PERMISSION MIGRATION ----------------------' + Style.RESET_ALL)


if __name__ == "__main__":
    main()