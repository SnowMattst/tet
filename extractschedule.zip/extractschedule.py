import argparse
import json
import os
import tempfile
import time as system_time
import xml.etree.ElementTree as ET

import numpy as np  # Import numpy for NaN handling
import openpyxl
import pandas as pd
import requests
import tableauserverclient as TSC
from openpyxl.styles import Font
from tableauserverclient import *

from config_reader.reader_factory import ReaderFactory
from connection import get_db_connection, login_to_tableau
from logger.logger import *

base_url = ""
cloud_url = ""

schedulesname = []
Type = []
type_name = []
frequency = []
log = []
migrate = []


def fetch_schedules_and_write_to_excel(database_credentials):
    try:
        # Get the database connection
        connection = get_db_connection(database_credentials)
        if connection is None:
            logger_error("Failed to connect to the database.")
            return None

        # Create a cursor object
        cursor = connection.cursor()

        # Execute a query to get PostgreSQL version
        cursor.execute("SELECT version();")
        db_version = cursor.fetchone()
        print(f"PostgreSQL database version: {db_version}")

        # Perform a query to get all data from the 'schedules' table
        sample_table = "schedules"  # Replace with an actual table name from your database
        query = f"SELECT * FROM {sample_table};"
        cursor.execute(query)

        # Fetch column headers
        col_names = [desc[0] for desc in cursor.description]

        # Fetch all rows
        rows = cursor.fetchall()

        # Create a pandas DataFrame
        df = pd.DataFrame(rows, columns=col_names)

        # Define the output file name
        output_file = 'schedules_data.xlsx'

        # Get the absolute path of the output file
        output_file_path = os.path.abspath(output_file)

        # Write the DataFrame to an Excel file
        df.to_excel(output_file_path, index=False)

        print(f"Data successfully written to {output_file_path}")

        # Close the cursor and connection
        cursor.close()
        connection.close()
        logger_info(f"File created in this location: {output_file_path}")
        # exit()
        return output_file_path

    except Exception as e:
        print(f"An error occurred: {e}")
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def get_project_id(projects, project_path, server):
    # Base case: If the project path is empty, return None
    if not project_path:
        return None

    current_project = None
    for project in projects:
        # Case-insensitive comparison
        if project.name.lower() == project_path[1].lower():
            current_project = project
            break

    if current_project is None:
        return None

    for part in project_path[2:]:
        child_projects = [
            p for p in projects if p.parent_id == current_project.id]
        current_project = None
        for child in child_projects:
            if child.name.lower() == part.lower():  # Case-insensitive comparison
                current_project = child
                break

        if current_project is None:
            return None

    return current_project.id


def get_days_from_decimal(days_decimal):
    days_binary = bin(int(days_decimal))[2:].zfill(7)
    days = []
    day_names = ["Sunday", "Monday", "Tuesday",
                 "Wednesday", "Thursday", "Friday", "Saturday"]
    for i, bit in enumerate(days_binary):
        if bit == '1':
            days.append(day_names[i])
    return days


def decode_days_of_week(mask):
    days = ["Sunday", "Monday", "Tuesday",
            "Wednesday", "Thursday", "Friday", "Saturday"]
    mask_int = int(mask)
    binary_mask = bin(mask_int)[2:][::-1]
    # Convert to binary and reverse for easy mapping
    schedule_days = [day for i, day in enumerate(
        days) if i < len(binary_mask) and binary_mask[i] == '1']
    return schedule_days


def convert_minutes_to_time(minutes):
    # Calculate the number of hours and convert to integer
    hours = int(minutes // 60)
    # Calculate the remaining minutes and convert to integer
    remaining_minutes = int(minutes % 60)
    # Format the time as HH:MM:SS
    return f"{hours:02}:{remaining_minutes:02}:00"


def migrate_extract_schedules(cloud_server, schedules_dir, database_credentials):
    """
    Publish the extract schedules to the cloud
    :param cloud_server: Tableau Server or Tableau Online instance
    :param schedules_dir: List of lists containing extract schedule names and file paths
    """
    api_version = "3.23"
    site_luid = cloud_server.site_id
    auth_token = cloud_server.auth_token
    excel_file_path = fetch_schedules_and_write_to_excel(database_credentials)
    # Read the Excel file into a DataFrame
    df = pd.read_excel(excel_file_path)
    cloud_workbooks = list(TSC.Pager(cloud_server.workbooks))
    cloud_datasources = list(TSC.Pager(cloud_server.datasources))
    cloud_projects = list(TSC.Pager(cloud_server.projects))
    for schedules in schedules_dir:
        file_path = schedules[0]
        with open(file_path, 'r') as file:
            datas = json.load(file)

        for data in datas:
            if data['task_type'] in ["extractRefresh", "IncrementExtractTask"]:
                current_project = get_project_ids(
                    data['destination'], cloud_server)
                data['datasource_workbook_id'] = None
                if current_project is not None:
                    if data['task_target_type'] == "workbook":
                        for workbook in cloud_workbooks:
                            if current_project == workbook.project_id:
                                if workbook.name == data['target_name']:
                                    data['datasource_workbook_id'] = workbook.id
                    elif data['task_target_type'] == "datasource":
                        for datasource in cloud_datasources:
                            if current_project == datasource.project_id:
                                if datasource.name == data['target_name']:
                                    data['datasource_workbook_id'] = datasource.id
                matching_schedule = df[df['name'] == data['schedule_name']]
                days = ''
                hours = ''
                end_schedule_time = ''
                if not matching_schedule.empty:
                    days_decimal = matching_schedule['day_of_week_mask'].values[0]
                    minute_interval = matching_schedule['minute_interval'].values[0]
                    end_time = matching_schedule['end_at_minute'].values[0]
                    if not np.isnan(days_decimal):
                        days = decode_days_of_week(days_decimal)

                    if not np.isnan(minute_interval):
                        # Convert minute_interval to hours and minutes
                        hours = int(minute_interval // 60)

                    if not np.isnan(minute_interval):
                        end_schedule_time = convert_minutes_to_time(end_time)

                url = f"{cloud_server.baseurl}/sites/{cloud_server.site_id}/tasks/extractRefreshes"
                headers = {
                    "Content-Type": "application/xml",
                    "X-Tableau-Auth": auth_token
                }
                if data['datasource_workbook_id']:
                    ts_request = ET.Element('tsRequest')
                    if data['task_type'] == "IncrementExtractTask":
                        extractRefresh_type = "incremental"
                    else:
                        extractRefresh_type = "FullRefresh"
                    extract_refresh = ET.SubElement(ts_request, 'extractRefresh', {
                                                    'type': data['task_type']})
                    datasource = ET.SubElement(extract_refresh, data['task_target_type'],
                                               {'id': data['datasource_workbook_id']})
                    schedule = ET.SubElement(ts_request, 'schedule', {
                                             'frequency': data['interval_type']})
                    frequency_details = None
                    if data['interval_type'] == "Hourly" and days is not None:
                        intervals = [
                            ET.Element('interval', {'hours': str(hours)}),
                        ]
                        # Add weekday intervals
                        for weekday in days:
                            interval_element = ET.Element(
                                'interval', {'weekDay': weekday})
                            intervals.append(interval_element)
                        frequency_details = ET.SubElement(schedule, 'frequencyDetails', {
                                                          'start': data['start_time'], 'end': data['end_time']})
                    elif data['interval_type'] == "Monthly" and data['interval'] and len(data['interval']) == 1:
                        intervals = []
                        for monthDay in data['interval']:
                            interval_element = ET.Element(
                                'interval', {'monthDay': monthDay})
                            intervals.append(interval_element)
                        frequency_details = ET.SubElement(schedule, 'frequencyDetails', {
                                                          'start': data['start_time']})
                    elif data['interval_type'] == "Daily" and days is not None:
                        intervals = [
                            ET.Element('interval', {'hours': str(hours)}),
                        ]
                        # Add weekday intervals
                        for weekday in days:
                            interval_element = ET.Element(
                                'interval', {'weekDay': weekday})
                            intervals.append(interval_element)
                        frequency_details = ET.SubElement(schedule, 'frequencyDetails', {
                                                          'start': data['start_time'], 'end': str(end_schedule_time)})
                    elif data['interval_type'] == "Weekly":
                        intervals = []
                        for weekday in data['interval']:
                            interval_element = ET.Element(
                                'interval', {'weekDay': weekday})
                            intervals.append(interval_element)
                        frequency_details = ET.SubElement(schedule, 'frequencyDetails', {
                                                          'start': data['start_time']})

                    if frequency_details is not None:
                        intervals_element = ET.SubElement(
                            frequency_details, 'intervals')
                        for interval in intervals:
                            intervals_element.append(interval)
                        payload = ET.tostring(ts_request)
                        try:
                            verify_ssl = cloud_server._http_options.get(
                                'verify', True)
                            response = requests.post(
                                url, headers=headers, data=payload, verify=verify_ssl)

                            if response.status_code == 200:
                                success_message = f"Extract schedule migration for {data['task_target_type']} '{data['target_name']}'"
                                success_message += f" with a frequency of {data['interval_type']} migrated successfully in project '{data['destination']}'."
                                logger_info(success_message)
                                schedulesname.append(data['schedule_name'])
                                Type.append(data['task_target_type'])
                                type_name.append(data['target_name'])
                                frequency.append(data['interval_type'])
                                log.append(
                                    f"Extract Schedule migrated successfully")
                                migrate.append('Migrated Extract Schedule')
                                # logger_info(f"Extract schedule migration for {data['task_target_type']} '{data['target_name']}' is successfully done.")
                            else:
                                logger_error(
                                    f"Failed to migrate extract schedule: {response.text}")
                                schedulesname.append(data['schedule_name'])
                                Type.append(data['task_target_type'])
                                type_name.append(data['target_name'])
                                frequency.append(data['interval_type'])
                                log.append(
                                    f"Failed to Migrate Extract Schedule: {response.text}")
                                migrate.append(
                                    'Failed to Migrate Extract Schedule')
                        except requests.exceptions.RequestException as e:
                            logger_error("Error:", e)
                            return None
                    else:
                        error_message = f"Failed to migrate extract schedule for {data['task_target_type']} '{data['target_name']}'"
                        error_message += f" for frequency {data['interval_type']}."
                        logger_error(error_message)
                        schedulesname.append(data['schedule_name'])
                        Type.append(data['task_target_type'])
                        type_name.append(data['target_name'])
                        frequency.append(data['interval_type'])
                        log.append(f"{error_message}")
                        migrate.append('Failed to Migrate Extract Schedule')
                else:
                    logger_error(
                        f"Failed to migrate extract schedule for {data['task_target_type']} '{data['target_name']}' in project '{data['destination']}'.")
                    schedulesname.append(data['schedule_name'])
                    Type.append(data['task_target_type'])
                    type_name.append(data['target_name'])
                    frequency.append(data['interval_type'])
                    log.append(
                        f"Failed to migrate extract schedule for {data['task_target_type']} '{data['target_name']}' in project '{data['destination']}")
                    migrate.append('Failed to Migrate Extract Schedule')

        log_data = pd.DataFrame({
            'Schedule Name': schedulesname,
            'Type': Type,
            'Type Name': type_name,
            'Frequency': frequency,
            'Log': log,
            'Status': migrate
        })

        file_name = 'migration_logs.xlsx'
        sheet_name = 'schedule'
        current_directory = os.getcwd()
        file_path = os.path.join(current_directory, file_name)

        try:
            workbook = openpyxl.load_workbook(file_path)
        except FileNotFoundError:
            workbook = openpyxl.Workbook()
            default_sheet = workbook["Sheet"]
            workbook.remove(default_sheet)

        if sheet_name not in workbook.sheetnames:
            workbook.create_sheet(sheet_name)

        sheet = workbook[sheet_name]
        sheet.delete_rows(1, sheet.max_row)

        sheet.append(log_data.columns.tolist())
        for cell in sheet[1]:
            cell.font = Font(bold=True)
        for row in log_data.itertuples(index=False, name=None):
            sheet.append(row)
        workbook.save(file_path)


def get_full_project_path(project_id, all_projects, server_obj):
    # Create a dictionary for quick lookup of projects by their ID
    project_lookup = {
        project.id: project for project in TSC.Pager(server_obj.projects)}

    path = []
    current_id = project_id

    while current_id:
        project = project_lookup.get(current_id)
        if not project:
            break
        project_name = project.name
        project_name = project_name.replace('/', '_fwd_SLASH_')
        path.append(project_name)
        current_id = project.parent_id

    # Reverse the path to get the full path from root to target project
    full_path = '/'.join(reversed(path))

    # Ensure the path starts with a '/'
    if not full_path.startswith('/'):
        full_path = '/' + full_path
    return full_path


def create_temp_dir(user_path=None):
    """
    Create a temporary directory in the specified path or the current directory.

    Args:
    user_path (str): The directory path where the temporary directory should be created.
                     If not specified, the current directory is used.

    Returns:
    str: The path to the created temporary directory.
    """
    # If user_path is provided, use it; otherwise, use the current working directory
    if user_path:
        # Ensure the path is absolute
        base_path = os.path.abspath(user_path)
    else:
        base_path = os.getcwd()

    # Ensure the base path exists
    if not os.path.exists(base_path):
        logger_error(f"The specified path does not exist: {base_path}")
        exit(1)

    # Check if we have permission to write in the directory
    if not os.access(base_path, os.W_OK):
        logger_error(f"Write permission denied for the path: {base_path}")
        exit(1)

    # Create a temporary directory within the specified path
    try:
        temp_dir = tempfile.mkdtemp(dir=base_path)
    except PermissionError as e:
        logger_error(f"Failed to create a temporary directory: {e}")
        exit(1)

    return temp_dir


def get_child_project_id(projects, project_path, server):
    # Base case: If the project path is empty, return None
    if not project_path:
        return None
    for project in projects:
        project_path_ = project_path[0].replace('_fwd_SLASH_', '/')
        if project.name.lower() == project_path_.lower():
            if len(project_path) == 1:
                return project.id
            else:
                child_projects = [p for p in TSC.Pager(
                    server.projects) if p.parent_id == project.id]
                child_project_id = get_child_project_id(
                    child_projects, project_path[1:], server)
                if child_project_id:
                    return child_project_id
    return None


def get_project_ids(path, server):
    all_projects = list(TSC.Pager(server.projects))
    main_path = path[1:]
    if '/' in main_path:
        path_parts = main_path.split('/')
        return get_child_project_id(all_projects, path_parts, server)
    else:
        for pro in all_projects:
            if pro.name.lower() == main_path.lower() and pro.parent_id is None:
                return pro.id
    return None


def download(server, project_paths, dest_project_paths):
    """
    Download extract schedules from the server for specific projects
    :param server: Server configuration details
    :param project_paths: List of project paths to filter schedules
    :param dest_project_paths: List of destination paths
    :return: List of schedules with their details
    """
    cloud_schedules = []

    # Create a mapping of project_paths to dest_project_paths
    project_to_dest_mapping = dict(zip(project_paths, dest_project_paths))
    try:
        server_obj, credentials = login_to_tableau(
            server['credentials']['server'])
        with server_obj.auth.sign_in(credentials):
            temp_dir = create_temp_dir()
            tasks, _ = server_obj.tasks.get()

            # Map project paths to project IDs
            project_ids = []
            for project_path in project_paths:
                current_parent_id = get_project_ids(project_path, server_obj)

                if current_parent_id:
                    project_ids.append(current_parent_id)

            previous_project_name = None
            destination_iterator = iter(dest_project_paths)

            # Get the first destination
            destination = next(destination_iterator, None)

            for task in tasks:
                if task.target.type == "workbook":
                    target_item = server_obj.workbooks.get_by_id(
                        task.target.id)
                elif task.target.type == "datasource":
                    target_item = server_obj.datasources.get_by_id(
                        task.target.id)
                else:
                    continue

                if target_item.project_id not in project_ids:
                    continue

                schedules = server_obj.schedules.get_by_id(task.schedule_id)
                interval_item = schedules.interval_item
                end_time = getattr(interval_item, 'end_time', 'N/A')
                target_id = target_item.id
                target_name = target_item.name

                project_name = get_full_project_path(
                    target_item.project_id, TSC.Pager(server_obj.projects), server_obj)
                if project_name != previous_project_name:
                    # Get the corresponding destination path from the mapping
                    destination = project_to_dest_mapping.get(
                        project_name, None)

                previous_project_name = project_name  # Update previous_project_name

                schedule_details = {
                    "start_time": str(interval_item.start_time),
                    "end_time": str(end_time),
                    "interval": interval_item.interval,
                    "task_type": task.task_type,
                    "priority": task.priority,
                    "target_name": target_name,
                    "target_id": target_id,
                    "interval_type": interval_item._frequency,
                    "schedule_name": schedules.name,
                    "task_target_type": task.target.type,
                    "project": project_name,
                    "destination": destination
                }
                cloud_schedules.append(schedule_details)
                logger_info(
                    f"Downloaded extract schedule for {task.target.type} '{target_name}'")

        json_file_path = os.path.join(temp_dir, "all_schedules.json")
        with open(json_file_path, "w") as json_file:
            json.dump(cloud_schedules, json_file, indent=4)

        logger_info("All extract schedules downloaded successfully")

    except Exception as e:
        logger_error(f"An error occurred: {e}")
    finally:
        cloud_schedules = []
        cloud_schedules.append([json_file_path])
    return cloud_schedules


def main():
    logger_info(f"::::Starting the migration extract-schedule ::::")
    start_time = system_time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None,
                        help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None,
                        help="Path to the .xlsx file containing project data.")
    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project

    if userpath:
        try:
            user_path = os.path.join(userpath, 'config.xml')
            config_file = ReaderFactory(user_path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(
                f"The specified config file does not exist in: {user_path}")
            exit(1)
    else:
        user_path = os.path.join(os.user_path.expanduser("~"), 'config.xml')
        config_file = ReaderFactory(user_path).reader().to_json()

    if excel_project:
        try:
            excel_path = os.path.join(excel_project, 'project_path.xlsx')
            project_file = pd.read_excel(excel_path)
        except FileNotFoundError as e:
            logger_error(
                f"The specified project mapping file does not exist in: {excel_path}")
            exit(1)
    else:
        excel_path = os.path.join(
            os.excel_path.expanduser("~"), 'project_path.xlsx')
        project_file = ReaderFactory(excel_path).reader().to_json()

    filtered_df = project_file[project_file['Select'].str.strip(
    ).str.lower() == 'yes']

    # Extract the 'source_path' column values from the filtered DataFrame
    project_paths = filtered_df['Source Project_path'].tolist()

    dest_project_paths = filtered_df['Destination Project_path'].tolist()

    temp_directory = download(config_file, project_paths, dest_project_paths)
    cloud_server, credentials = login_to_tableau(
        config_file['credentials']['cloud'])
    with cloud_server.auth.sign_in(credentials):
        migrate_extract_schedules(
            cloud_server, temp_directory, config_file["credentials"]["database"])
        end_time = system_time.time()
        total_time_seconds = end_time - start_time
        minutes = int(total_time_seconds // 60)
        seconds = int(total_time_seconds % 60)
        logger_info(
            f"::::Execution time for migration extract-schedule is: {minutes} min {seconds} sec::::"
        )


if __name__ == "__main__":
    main()
