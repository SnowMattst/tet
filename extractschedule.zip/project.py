from tabulate import tabulate
from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from requests.exceptions import HTTPError
from openpyxl.styles import Font
from pandas import DataFrame,notna,read_excel
from connection import login_to_tableau,get_project_ids,get_all_items,get_full_project_path
from tableauserverclient import ProjectItem,ServerResponseError
import os, argparse,time,openpyxl

Project_names = []
log = []
migrate = []

def get_projects(server, project_files):
    project_list = get_all_items(server,'project')
    query_project = []
    filtered_df = project_files[project_files['Select'].str.lower() == 'yes'].values.tolist()
    if len(filtered_df) == 0:
        for project in project_list:
            if project.name != 'Default':
                query_project.append({'name': project.name, 'description': project.description,
                                      'content_permissions': project.content_permissions,
                                      'parent_id': project.parent_id, 'project_path':
                                          get_full_project_path(project_list, project.id)})
    else:
        for filter_data in filtered_df:
            project_path = '/'.join(filter_data[0].split('/')[:-1])
            project_id = get_project_ids(filter_data[0],server)

            if project_id is not None:
                for project in project_list:
                    if project_id == project.id:
                        query_project.append({'name': project.name, 'description': project.description,
                                              'content_permissions': project.content_permissions,
                                              'parent_id': project.parent_id, 'project_path': filter_data[0],'project_path2':project_path})
            else:
                Project_names.append(filter_data[0])
                log.append(f"Project with the path: {filter_data[0]} Not found")
                migrate.append(f"Project not migrated")
                logger_error(f"Project with the path: {filter_data[0]} Not found")

    return query_project


def create_project_project(cloud_server, project_lists, filterd_projects):
    for project_list in project_lists:
        for filter_project in filterd_projects.values.tolist():
            if project_list['project_path'] == filter_project[0] and notna(filter_project[1]):
                project_list['project_path2'] = filter_project[1]
                project_path=project_list['project_path2']
                project_id=get_project_ids(project_path,cloud_server)
                project_list['parent_id'] = project_id
                project_list['project_path'] = project_path
                if project_id is None:
                    Project_names.append(f"{project_list['name']} Path:{project_list['project_path']}")
                    log.append(f"Project with the path: {project_path} Not found")
                    migrate.append(f"Project not migrated")
                    logger_error(f'Project with the path {project_path} does not exist')
                    project_lists.remove(project_list)
    project_lists = sorted(project_lists, key=lambda x: x['project_path'].count('/'))
    for project_list in project_lists:
        request_xml(cloud_server, project_list,)

def request_xml(cloud_server, project):
    """
    Creates a new project on the Tableau Server using the provided project details.

    Args:
        cloud_server: The Tableau Server object representing the cloud server.
        project (dict): A dictionary containing project details, including name, content_permissions, description, and parent_id.

    Returns:
        None.
    """
    try:
        if project['parent_id'] is None:
            new_project = ProjectItem(name=project['name'], content_permissions=project['content_permissions'],description=project['description'], parent_id=None)
            cloud_server.projects.create(new_project)
            logger_info(f'Project "{project["name"]}" Migrated in [{project["project_path"]}] path')
            Project_names.append(f"{project['name']} Path:{project['project_path']}")
            log.append("Successfully migrated project")
            migrate.append(f"Project migrated")
        else:
            parent_id = get_project_ids(project['project_path2'], cloud_server)
            if parent_id is not None:
                new_project =ProjectItem(name=project['name'], content_permissions=project['content_permissions'],description=project['description'], parent_id=parent_id)
                cloud_server.projects.create(new_project)
                logger_info(f'Project "{project["name"]}" Migrated in [{project["project_path"]}] path')
                Project_names.append(f"{project['name']} Path:{project['project_path']}")
                log.append("Successfully migrated project")
                migrate.append(f"Project migrated")
            else:
                Project_names.append(f"{project['name']},Path:{project['project_path']}")
                log.append(f"Project with the path: {project} Not found")
                migrate.append(f"Project not migrated")
                logger_error(f'Project with path :[{project["project_path"]}] not found')

    # Handle specific exceptions.
    except HTTPError as http_err:
        Project_names.append(f"{project['name']},Path:{project['project_path']}")
        log.append(f"HTTP error occurred: {http_err}")
        migrate.append(f"Project not migrated")
        logger_error(f"HTTP error occurred: {http_err}")
    except ServerResponseError as server_err:
        Project_names.append(f"{project['name']},Path:{project['project_path']}")
        log.append(f"Tableau Server error occurred for project: {server_err}")
        migrate.append(f"Project not migrated")
        logger_error(f"Tableau Server error occurred for project: {project['name']}: {server_err}")
    except Exception as e:
        logger_error(f"An unexpected error occurred: {e}")
def main():
    """
    Main executor function
    :return:
    """
    logger_info("::: Starting the Project Migration :::")
    start_time = time.time()

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--project", type=str, default=None, help="Path to the .xlsx file containing project data.")


    args = parser.parse_args()
    userpath = args.config
    excel_project = args.project

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config_file = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a config file path")

    if excel_project:
        try:
            path = os.path.join(excel_project, 'project_path.xlsx')
            project_file = read_excel(path)
        except FileNotFoundError as e:
            logger_error(f"The specified project mapping file does not exist in: {path}")
            exit(1)
    else:
        logger_error("Please Specify a Project Mapping file path")

    # Login to the tableau server
    tableau_server=login_to_tableau(config_file["credentials"]['server'])
    with tableau_server[0].auth.sign_in(tableau_server[1]):
        dist= get_projects(tableau_server[0],project_file)

    print(Fore.YELLOW + "\n\nProjects :::\n" + Style.RESET_ALL)
    details_data = [
        [detail["name"], detail["project_path"]]
        for detail in dist
    ]
    details_headers = ["Project Name ", "project_path"]
    print(Fore.CYAN + tabulate(details_data, headers=details_headers, tablefmt="grid") + Style.RESET_ALL)

    # Login to the cloud server
    tableau_cloud=login_to_tableau(config_file["credentials"]['cloud'])
    with tableau_cloud[0].auth.sign_in(tableau_cloud[1]):
        create_project_project(tableau_cloud[0], dist, project_file)

    log_data = DataFrame({
        'Project Name': Project_names,
        'Log': log,
        'Status': migrate
    })

    file_name='migration_logs.xlsx'
    sheet_name = 'Project'
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, file_name)

    try:
        workbook = openpyxl.load_workbook(file_path)
    except FileNotFoundError:
        workbook = openpyxl.Workbook()
        default_sheet = workbook["Sheet"]
        workbook.remove(default_sheet)

    if sheet_name not in workbook.sheetnames:
        workbook.create_sheet(sheet_name)

    sheet = workbook[sheet_name]
    sheet.delete_rows(1, sheet.max_row)
    sheet.append(log_data.columns.tolist())
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for row in log_data.itertuples(index=False, name=None):
        sheet.append(row)
    workbook.save(file_path)
    end_time = time.time()
    diff = end_time - start_time
    minutes, seconds = divmod(diff, 60)
    logger_info(f":::: Execution time for migrating Project is: {int(minutes)} min {int(seconds)} sec ::::")
    logger_info(f":::: Migration log file generated : {file_path} ::::")
    print(Fore.YELLOW + '\n\t\t\t---------------------- END OF PROJECT MIGRATION ----------------------' + Style.RESET_ALL)



if __name__ == "__main__":
    main()