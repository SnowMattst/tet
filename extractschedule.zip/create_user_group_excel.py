import argparse
import os

from connection import login_to_tableau,get_all_items
from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from  pandas import  DataFrame,ExcelWriter


def create_excel_csv(filename,server):


    tableau_server=login_to_tableau(server["credentials"]["server"])
    with tableau_server[0].auth.sign_in(tableau_server[1]):
        user_email=[]
        user_name=[]

        group_name=[]
        for user in get_all_items(tableau_server[0],'user'):
            user_name.append(user.name)
            user_email.append(user.email)
        for user in get_all_items(tableau_server[0],'group'):
            group_name.append(user.name)
        # Create separate DataFrames for users and groups
        df_users = DataFrame({
            'Source User_Email': user_email,
            'Source User_Name': user_name,
            'Destination User_Email': user_email
        })

        df_groups = DataFrame({
            'Source Group Name': group_name,
            'Destination Group Name': group_name,
            'Select': 'no',
        })

        # Write the DataFrames to separate sheets in an Excel file
        with ExcelWriter(filename) as writer:
            df_users.to_excel(writer, sheet_name='Users', index=False)
            df_groups.to_excel(writer, sheet_name='Groups', index=False)
    return filename


def main():
    """
    Main executor function
    :return:
    """
    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    args = parser.parse_args()
    userpath = args.config
    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        try:
            path = os.path.join(os.path.expanduser("~"), 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    # File name for the Excel file
    filename = 'user_mapping.xlsx'
    try:
        # Create an Excel file with dummy data
        file_path = create_excel_csv(filename, config)
        logger_info(f"File created at: {file_path}")

    except PermissionError:
        logger_error("Permission error occurred during file creation.")

    except FileNotFoundError:
        logger_error("File not found error occurred during file creation.")

    except Exception as e:
        logger_error(f"An unexpected error occurred during file creation: {e}")

if __name__ == "__main__":
    main()