import os
import sys
import tempfile
from pathlib import Path

from config_reader.reader_factory import ReaderFactory


class MSystemVariables:

    def __init__(self, name, version):
        self.name = name
        self.version = version
        # find the parent directory of the current file
        self.parent_dir = Path.home()
        path_to_config = os.path.join(self.parent_dir, "storm", "storm-config.xml")
        self.config = ReaderFactory(path_to_config).reader().to_json()
        self.os = sys.platform
        self.version = sys.version_info.major
        self.temp_dir = tempfile.NamedTemporaryFile().name
        self.output_dir = os.path.join(self.parent_dir, "output")
        # self.source = self.config["migrations"]["datasources"]["server"]["@path"]
        # self.cloud = self.config["migrations"]["datasources"]["clouds"]["server"][
        #    "@path"
        # ]


sys_variables = MSystemVariables("on-prem_to_cloud", 1.0)
