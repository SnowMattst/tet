import argparse
import json
import os
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

import openpyxl
from openpyxl import load_workbook
import requests
from openpyxl.utils import get_column_letter
from tableauserverclient import *
from pandas import read_excel as pd_read_excel
from config_reader.reader_factory import ReaderFactory
from logger.logger import *
from connection import login_to_tableau


def download(server_filters):
        server,credentials = login_to_tableau(server_filters['credentials']['server'])
        with server.auth.sign_in(credentials):
            users = server.users.get()[0]
            groups = server.groups.get()[0]
            for u in users:
                print(u.name)



class Resource:
    def __init__(self, server):
        self.server = server
        self.users = server.users.get()[0]
        self.groups = server.groups.get()[0]

        self.migrated_users = []
        self.unmigrated_users = []

        self.migrated_groups = []
        self.unmigrated_groups = []

        self.added_users_to_groups = {}

        self.roles_mapping = {
            "SiteAdministratorExplorer": "SiteAdministratorExplorer",
            "Unlicensed": "Unlicensed",
            "SiteAdministratorCreator": "SiteAdministratorCreator",
            "ServerAdministrator": "SiteAdministratorCreator",
            "Viewer": "Viewer",
            "ExplorerCanPublish": "ExplorerCanPublish",
            "Creator": "Creator",
            "Explorer": "Explorer",
            "Guest": "Guest",
            "Interactor": "Interactor",
            "Publisher": "Publisher",
            "ReadOnly": "ReadOnly",
            "SiteAdministrator": "SiteAdministrator",
            "SupportUser": "SupportUser",
            "UnlicensedWithPublish": "UnlicensedWithPublish",
            "ViewerWithPublish": "ViewerWithPublish",
        }

        self.wb = openpyxl.Workbook()


    def dump_groups_to_file(self):
        """
        Dump Data to excel file
        {g.name}")
            logger_info(f"\tSource server information:")
            logger_info(f"\t\tLicense Mode: {g.license_mode}")
            logger_info(f"\t\tTag name : {g.tag_name}")
            logger_info(f"\t\tMinimum Site Role : {g.minimum_site_role}")
        :return:
        """
        # Name of the output file
        output_file = "migration_logs.xlsx"
        # Create a new Workbook
        wb = load_workbook(output_file)
        sheet = wb.create_sheet(title=f'Group Success')
        # Headers
        sheet.append(['Name', 'ID'])
        # Write data from the list to the success sheet
        for row_idx, value in enumerate(self.migrated_groups, start=1):
            sheet.cell(row=row_idx, column=1).value = value.name
            sheet.cell(row=row_idx, column=2).value = value.id

        sheet = wb.create_sheet(title=f'Group Failed')
        sheet.append(['Name', 'ID'])
        # Write data from the list to the failed sheet
        for row_idx, value in enumerate(self.unmigrated_groups, start=1):
            sheet.cell(row=row_idx, column=1).value = value.name
            sheet.cell(row=row_idx, column=2).value = value.id

        #wb.remove(self.wb["Sheet"])

        # Save the workbook
        wb.save(output_file)
        print(f"List successfully written to {output_file}")

    def dump_data_to_file(self):
        """
        Dump Data to excel file
        :return:
        """
        # Name of the output file
        output_file = "migration_logs.xlsx"
        wb = load_workbook(output_file)
        sheet = wb.create_sheet(title=f'User Success')
        # Headers
        sheet.append(['Email', 'Name', 'ID'])
        # Write data from the list to the success sheet
        for row_idx, value in enumerate(self.migrated_users, start=1):
            sheet.cell(row=row_idx, column=1).value = value.email
            sheet.cell(row=row_idx, column=2).value = value.name
            sheet.cell(row=row_idx, column=3).value = value.id

        sheet = wb.create_sheet(title=f'User Failed')
        sheet.append(['Email', 'Name', 'ID'])
        # Write data from the list to the failed sheet
        for row_idx, value in enumerate(self.unmigrated_users, start=1):
            sheet.cell(row=row_idx, column=1).value = value.email
            sheet.cell(row=row_idx, column=2).value = value.name
            sheet.cell(row=row_idx, column=3).value = value.id

        # Save the workbook
        wb.save(output_file)
        print(f"List successfully written to {output_file}")


    def added_users_to_groups_migration_to_file(self):
        """
        Dump Data to excel file
        :return:
        """
        try:
            # Define the filename
            filename = 'migration_logs.xlsx'
            wb = load_workbook(filename)
            # Create a new workbook and select the active worksheet
            ws = wb.create_sheet(title=f'User Added to Group')

            # Set the header
            headers = ['Category', 'Status', 'Emails']
            for col_num, header in enumerate(headers, 1):
                col_letter = get_column_letter(col_num)
                ws[f"{col_letter}1"] = header

            # Write data to worksheet
            row_num = 2
            for category, statuses in self.added_users_to_groups.items():
                for status, emails in statuses.items():
                    for email in emails:
                        ws[f"A{row_num}"] = category
                        ws[f"B{row_num}"] = status
                        ws[f"C{row_num}"] = email
                        row_num += 1

            # Save the workbook to a file
            wb.save(filename)
            print(f"Data successfully written to {filename}")
        except Exception as e:
            print(f"An error occurred: {e}")

    def add_users_to_group(self, target_server, site_role, email, user_id, group_id):
            # Build the XML request
            ts_request = ET.Element('tsRequest')
            user_element = ET.SubElement(ts_request, 'user')
            user_element.set('id', user_id)
            user_element.set('name', email)
            user_element.set('siteRole', site_role)

            # Convert the XML to a string
            xml_request = ET.tostring(ts_request, encoding='unicode')

            base_url = target_server.server.baseurl
            auth_token = target_server.server.auth_token
            site_id = target_server.server.site_id
            # Define the endpoint URL
            url = f"{base_url}/sites/{site_id}/groups/{group_id}/users"

            # Set the headers
            headers = {
                'X-Tableau-Auth': auth_token,
                'Content-Type': 'application/xml',
                "Accept": "application/json",
            }

            # Make the API request
            response = requests.post(url, headers=headers, data=xml_request)

            # Handle errors
            if response.status_code == 200:
                return True
            else:
                # Handle different error conditions
                if response.status_code == 400:
                    raise ValueError(
                        "Bad request: The content of the request body is missing or incomplete, or contains malformed XML.")
                elif response.status_code == 404:
                    if "Site not found" in response.text:
                        raise ValueError("Site not found: The site ID in the URI doesn't correspond to an existing site.")
                    elif "Group not found" in response.text:
                        raise ValueError(
                            "Group not found: The group name in the request body doesn't correspond to an existing group.")
                elif response.status_code == 405:
                    raise ValueError("Invalid request method: Request type was not POST.")
                elif response.status_code == 409:
                    raise ValueError("User conflict: The specified user is already a member of the group.")
                else:
                    response.raise_for_status()

    def get_group_by_name(self, group_name):
        """
        Return the ID of the group
        :param group_name:
        :return:
        """
        for g in self.groups:
            if g.name == group_name:
                return g
        return None

    def get_user_email(self, name):
        """
        Return the ID of the user
        :param name:
        :return:
        """
        for u in self.users:
            if u.name == name:
                return u.email
        return None

    def get_userid_by_email(self, email):
        """
        Return the ID of the user
        :param name:
        :return:
        """
        for u in self.users:
            if u.email.lower() == email.lower():
                return u.id, u.email
        return None, None

    def get_group_id_by_name(self, name):
        """
        Return the ID of the group
        :param name:
        :return:
        """
        for g in self.groups:
            if g.name == name:
                return g.id
        return None

    def get_site_role_of_user(self, name):
        """
        Get the site role of the user
        :param name:
        :return:
        """
        for u in self.users:
            if u.name.lower() == name.lower():
                return u.site_role
        return None

    def migrate_group_users_to_cloud_group(self, target_server, group_map):
        """
        Assign all the users of a group to cloud group
        :param target_server:
        :return:
        """
        for source_group, val in group_map.items():
            if source_group != "All Users":
                target_group_f = val[0]
                required = val[1]

                if target_group_f and required.lower() in ['yes', 'true', 'ok']:
                    s_gp = self.get_group_by_name(source_group)

                    # Populate users in a group
                    self.server.groups.populate_users(s_gp)

                    users_in_group = []
                    for user in s_gp.users:
                        email = self.get_user_email(user.name)
                        if email:
                            users_in_group.append(email)

                    logger_info(f"\nMigrating users from source server group : {s_gp.name} to cloud server group : {target_group_f} "
                                f"with members : {users_in_group}")
                    self.added_users_to_groups[target_group_f] = {
                        "Added" : [],
                        "Failed": [],
                    }
                    for user in users_in_group:
                        target_group = target_group_f
                        logger_info(f"\t\tAdding user : {user} to cloud group : {target_group}")
                        user_id_cloud, target_email = target_server.get_userid_by_email(user)
                        if user_id_cloud:
                            target_group_c = target_server.get_group_by_name(target_group)
                            site_role = target_server.get_site_role_of_user(user)
                            group_id = target_group_c.id
                            try:
                                response = self.add_users_to_group(target_server, site_role, target_email, user_id_cloud, group_id)
                                if response:
                                    logger_info(f"\t\tSuccessfully added user to cloud group : {target_group}")
                                    self.added_users_to_groups[target_group_f]["Added"].append(user)
                            except Exception as e:
                                print(e)
                                self.added_users_to_groups[target_group_f]["Failed"].append(user)
                                continue
                        else:
                            logger_error(f"No user found with this name {user} in cloud.")

    def migrate_groups(self, target_server):
        """
        Migrate all the groups from the source server to the cloud server
        :param target_server:
        :return:
        """
        for pos, g in enumerate(self.groups):
            logger_info(f"\nMigrating group : {g.name}")
            logger_info(f"\tSource server information:")
            logger_info(f"\t\tLicense Mode: {g.license_mode}")
            logger_info(f"\t\tTag name : {g.tag_name}")
            logger_info(f"\t\tMinimum Site Role : {g.minimum_site_role}")

            if g.name == "All Users":
                logger_info(f"\nSkipping group {g.name} as it is a default group in every server.")
                continue

            logger_info(f"\n\tMigrating group to the cloud server")
            try:
                newgroup = GroupItem(g.name)
                newgroup.minimum_site_role = g.minimum_site_role
                newgroup.license_mode = g.license_mode
                newgroup.domain_name = g.domain_name
                response = target_server.server.groups.create(newgroup)
                logger_info(f"\t\tMigrated group to the cloud server with name : {g.name}")
                self.migrated_groups.append(g)
            except Exception as e:
                logger_error(f"\t\tFailed to migrate group to the cloud server : {e}")
                logger_error(traceback.print_exception(*sys.exc_info()))
                self.unmigrated_groups.append(g)


    def migrate_users(self, target_server):
        """
        Migrate all the users from the source server to the cloud server
        :param target_server:
        :return:
        """
        for pos, u in enumerate(self.users):
            logger_info(f"\nMigrating user : {u.name}")
            logger_info(f"\tSource server information:")
            logger_info(f"\t\tSite Role: {u.site_role}")
            logger_info(f"\t\tEmail : {u.email}")
            logger_info(f"\t\tAuth Setting : {u.auth_setting}")

            if u.email:
                logger_info(f"\n\tMigrating user to the cloud server")
                site_role = self.roles_mapping[u.site_role]
                user_item = UserItem(u.email, site_role, auth_setting=u.Auth.TableauIDWithMFA)
                try:
                    response = target_server.server.users.add(user_item)
                    self.migrated_users.append(u)

                    logger_info(f"\t\tMigrated user to the cloud server")
                except Exception as e:
                    logger_error(f"\t\tFailed to migrate user to the cloud server")
                    logger_error(traceback.print_exception(*sys.exc_info()))
                    self.unmigrated_users.append(u)

            else:
                logger_error(f"\nSkipping user {u.name} as it has no email address")
                logger_error(traceback.print_exception(*sys.exc_info()))
                self.unmigrated_users.append(u)

class UserGroupMigrate:
    def __init__(self, config, csv_data, all_users_migrate=False, all_groups_migrate=False, migrate_group_users=False):

        # config
        self.config = config

        self.source_server = self.get_source_servers()
        self.cloud_servers = self.get_cloud_servers()

        # mapping groups
        self.csv_data = csv_data

        # Build the group mapping dict
        self.group_map = {}
        source_group = csv_data['Source Group Name']
        dest_group = csv_data['Destination Group Name']
        required = csv_data['Select']
        for pos, val in source_group.items():
            s_gp_name = val
            d_gp_name = dest_group[pos]
            req = required[pos]
            self.group_map[s_gp_name] = [d_gp_name, req]

        # settings
        self.all_users_migrate = all_users_migrate
        self.all_groups_migrate = all_groups_migrate
        self.migrate_group_users = migrate_group_users

    def migrate_group_users_to_cloud(self):
        """
        Assign the group users to cloud group
        :return:
        """
        if self.migrate_group_users:
            print("==========================================================================")
            logger_info("MIGRATING GROUP MEMBERS FROM SOURCE GROUP TO DESTINATION GROUP ::::")
            print("==========================================================================")
            for value in self.source_server:
                for target in self.cloud_servers:
                    source_server, source_credentials = value
                    target_server, target_credentials = target
                    with source_server.auth.sign_in(source_credentials):
                        with target_server.auth.sign_in(target_credentials):
                            source_server_resource = Resource(source_server)
                            target_server_resource = Resource(target_server)

                            # Migrate all the users to target source server
                            source_server_resource.migrate_group_users_to_cloud_group(target_server_resource,
                                                                                      self.group_map)
                            source_server_resource.added_users_to_groups_migration_to_file()

    def migrate_users(self):
        """
        Migrate all the users from the source server to the cloud server
        :return:
        """
        if self.all_users_migrate:
            print("================================================================")
            logger_info("MIGRATING ALL USERS ::::")
            print("================================================================")
            for value in self.source_server:
                for target in self.cloud_servers:
                    source_server, source_credentials = value
                    target_server, target_credentials = target
                    with source_server.auth.sign_in(source_credentials):
                        with target_server.auth.sign_in(target_credentials):
                            source_server_resource = Resource(source_server)
                            target_server_resource = Resource(target_server)

                            # Migrate all the users to target source server
                            source_server_resource.migrate_users(target_server_resource)
                            source_server_resource.dump_data_to_file()

    def migrate_groups(self):
        """
        Migrate all the groups from the source server to the cloud server
        :return:
        """
        if self.all_groups_migrate:
            print("================================================================")
            logger_info("MIGRATING ALL GROUPS ::::")
            print("================================================================")
            for value in self.source_server:
                for target in self.cloud_servers:
                    source_server, source_credentials = value
                    target_server, target_credentials = target
                    with source_server.auth.sign_in(source_credentials):
                        with target_server.auth.sign_in(target_credentials):
                            source_server_resource = Resource(source_server)
                            target_server_resource = Resource(target_server)

                            # Migrate all the groups to target source server
                            source_server_resource.migrate_groups(target_server_resource)
                            source_server_resource.dump_groups_to_file()

    def get_cloud_servers(self):
        """
        Get the cloud servers
        :param config:
        :return:
        """
        server = self.config['credentials']['cloud']['@path']
        pat_name = self.config['credentials']['cloud']['@pat_name']
        pat_secret = self.config['credentials']['cloud']['@pat']
        site = self.config['credentials']['cloud']['@site']
        credentials = PersonalAccessTokenAuth(
            token_name=pat_name, personal_access_token=pat_secret, site_id=site
        )
        cloud_server = Server(server, use_server_version=True)

        return [[cloud_server, credentials]]

    def get_source_servers(self):
        """
        Get the source servers
        :param config:
        :return:
        """
        servers=[]
        # create a server object
        server,credentials =login_to_tableau(self.config["credentials"]["server"])

        servers.append([server, credentials])

        return servers







def main():
    """
    Main executor function
    :return:
    """
    start = time.time()
    end = time.time()
    logger_info("Starting the migration of users and groups")

    parser = argparse.ArgumentParser(description="Read and parse an XML file.")
    parser.add_argument("--config", type=str, default=None, help="Path to the XML file.")
    parser.add_argument("--user", type=str, default=None, help="Path to the CSV file.")
    args = parser.parse_args()
    userpath = args.config
    csv_userpath = args.user

    file_path = 'migration_logs.xlsx'
    if not os.path.exists(file_path):
        # Create a migration log file. Ignore if present
        workbook = openpyxl.Workbook()
        sheet = workbook.active

        # Save the workbook
        workbook.save(file_path)
        logger_info(f"Migration log file generated : {file_path}")
    else:
        logger_info(f"Migration log file present : {file_path}")

    if userpath:
        try:
            path = os.path.join(userpath, 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        try:
            path = os.path.join(Path.home(), 'config.xml')
            config = ReaderFactory(path).reader().to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)

    if csv_userpath:
        try:
            path = os.path.join(csv_userpath, 'user_mapping.xlsx')
            reader_factory = ReaderFactory(path)
            reader = reader_factory.reader()
            reader.read()
            csv_data = reader.to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)
    else:
        try:
            path = os.path.join(Path.home(), 'source_data.csv')
            reader_factory = ReaderFactory(path)
            reader = reader_factory.reader()
            reader.read()
            csv_data = reader.to_json()
        except FileNotFoundError as e:
            logger_error(f"The specified config file does not exist in : {path}")
            exit(1)

    # print("config",csv_data)

    # Parse the JSON string into a list of dictionaries
    csv_data = pd_read_excel(path, sheet_name='Groups')
    csv_data = json.loads(csv_data.to_json())

    # Download the datasources from the server
    ugmigrate = UserGroupMigrate(config, csv_data, all_users_migrate=True, all_groups_migrate=True,
                                 migrate_group_users=True)

    for filter in config['credentials']['users_groups']['filters']['filter']:
        if filter['@value'] == 'all_users' and filter['@enabled'].lower() == 'true':
            ugmigrate.migrate_users()
        if filter['@value'] == 'all_groups' and filter['@enabled'].lower() == 'true':
            ugmigrate.migrate_groups()

    ugmigrate.migrate_group_users_to_cloud()


    # convert the time difference to minutes
    minutes = end - start
    logger_info(f"Users and groups migration completed successfully in {minutes} Seconds.")


if __name__ == "__main__":
    main()